<?php
function set_user_subscription_plan_payment($user_id , $plan_id, $plan_type_id , $total_amount , $currency ,$value_return_payment , $payment_method ,$transaction_ID){
    try{
        global $wpdb;
        $Db_insert = array(
                        'user_id'=>$user_id,
                    	'plan_id'=>$plan_id,
                    	'plan_type_id'=>$plan_type_id,
                    	'payment_method'=>$payment_method,
                    	'total_amount'=>$total_amount,
                    	'currency'=>$currency,
                    	'payment_return_value'=>$value_return_payment,
                    	'transaction_ID'=>$transaction_ID,
                    		   
                );
            $db =  $wpdb->insert( user_plan_payment_info_db_name(), $Db_insert);
            $this_insert = $wpdb->insert_id;
                            
            update_user_meta($user_id,'user_current_subscription_plan',$plan_id);
            update_user_meta($user_id,'user_current_subscription_plan_payment_info',$this_insert);
                            
            return $this_insert ;       
            
    }catch( Exception $e){
        throw new Exception($e->getMessage());
        return 0;
    }
}
function set_user_status_subscription_plan( $user_id , $plan_id,  $plan_type_id ,  $user_payment_id){
    try{
        global $wpdb;
        
        $is_installment = false;
        $previous_installment_user_plan_id = -1;
        $current_installment_pay_running = -1;
        $is_installment_pay_finish = false;
        $is_payment_complete = true;
        $current_status = "active";
        $starting_date = strtotime("now");
        $expiry_date = "";
        $result = get_a_plan($plan_id);
        if($plan_type_id == 2){
                $previous_plan_user_status_id = get_user_meta( $user_id, 'user_current_subscription_plan_user_status_info' , true );
                
                    if(!$previous_plan_user_status_id){
                            $is_installment = true;
                            $previous_installment_user_plan_id = -1;
                            $current_installment_pay_running = 1;
                            $is_installment_pay_finish = false;
                            $is_payment_complete = false;
                            $current_status = "active";
                            $starting_date = strtotime("now");
                            $expiry_date = strtotime("+30 day");
                            if($result[0]->plan_number_payment == $current_installment_pay_running){
                                    $is_installment_pay_finish = true;
                                    $is_payment_complete = true;
                                    $expiry_date = "";
                                }
                            }
                            else{
                                    
                                $results = $wpdb->get_results( 
                                            "SELECT * FROM `".user_plan_status_info_db_name()."` WHERE `ID` = ".$previous_plan_user_status_id 
                                        );
                                $value = $results[0];
                                $is_installment = true;
                                $previous_installment_user_plan_id = $value->ID;
                                $current_installment_pay_running = $value->current_installment_pay_running + 1;
                                $is_installment_pay_finish = false;
                                $is_payment_complete = false;
                                $current_status = "active";
                                $starting_date = strtotime("now");
                                $expiry_date = strtotime("+30 day");
                                if($result[0]->plan_number_payment == $current_installment_pay_running){
                                    $is_installment_pay_finish = true;
                                    $is_payment_complete = true;
                                    $expiry_date = "";
                                }
                            }
                        }
                            
                        if($plan_type_id == 3){
                            $is_installment = false;
                            $previous_installment_user_plan_id = -1;
                            $current_installment_pay_running = -1;
                            $is_installment_pay_finish = false;
                            $is_payment_complete = true;
                            $current_status = "active";
                            $starting_date = strtotime("now");
                            $expiry_date = strtotime("+30 day");
                        }
                        if($plan_type_id == 4){
                            $is_installment = false;
                            $previous_installment_user_plan_id = -1;
                            $current_installment_pay_running = -1;
                            $is_installment_pay_finish = false;
                            $is_payment_complete = false;
                            $current_status = "active";
                            $starting_date = strtotime("now");
                            $expiry_date = "";
                        }
                        
                        
                        $Db_insert = array(
                                'user_id'=>$user_id,                                                            //user id
                    		    'plan_id'=>$plan_id,                                                            //plan all info db id
                    		    'plan_type_id'=>$plan_type_id,
                    		    'last_payment_id'=>$user_payment_id,                                            //relation with user payment id
                    		    'is_installment'=>$is_installment,                                              //check is installment
                    		    'previous_installment_user_plan_id'=>$previous_installment_user_plan_id,         //parent installment id from user plan status table
                    		    'is_installment_pay_finish'=>$is_installment_pay_finish,                        // installment is complete
                    		    'current_installment_pay_running'=>$current_installment_pay_running,            // current installment is number
                    		    'current_status'=>$current_status,                                               // user plan status which is active or deactivate
                    		    'is_payment_complete'=>$is_payment_complete,                                    // user is payment complete
                    		    'starting_date'=>$starting_date,
                    		    'expiry_date'=>$expiry_date,
                            );
                            $db =  $wpdb->insert( user_plan_status_info_db_name(), $Db_insert);
                            $this_insert = $wpdb->insert_id;
                            update_user_meta($user_id,'user_current_subscription_plan_user_status_info',$this_insert);
                                
          return $this_insert; 
    }catch( Exception $e){
        throw new Exception($e->getMessage());
        return 0;
    }
}

function user_canceled_subscription_plan($user_id){
             global $wpdb;
          
            $user_Info = get_userdata( $user_id );
            $user_email = $user_Info->user_email;
            
            $plan_info = get_user_meta( $user_id, 'user_current_subscription_plan' , true );
            $plan_payment_info = get_user_meta( $user_id, 'user_current_subscription_plan_payment_info' , true );
            $plan_status_info = get_user_meta( $user_id, 'user_current_subscription_plan_user_status_info' , true );
            
            $Db_upgrade = array(
                        'current_status'=>'deactivate',
                );
            $updated = $wpdb->update( user_plan_status_info_db_name(), $Db_upgrade , array("ID"=>$plan_status_info) );
            
            
            if(get_user_meta( $user_id, 'user_current_subscription_plan' , true )){
                if ( ! delete_user_meta($user_id, 'user_current_subscription_plan') ) {
                   
                   
                    $Db_upgrade = array(
                        'current_status'=>'active',
                    );
                    $updated = $wpdb->update( user_plan_status_info_db_name(), $Db_upgrade , array("ID"=>$plan_status_info) );
                     update_user_meta($user_id,'user_current_subscription_plan',$plan_info);
                    return json_encode(array('status'=>"0","message"=> "Not Canceled Plan Please Contact us " ));
                }
                
            }
            if(get_user_meta( $user_id, 'user_current_subscription_plan_payment_info' , true )){
                 if ( ! delete_user_meta($user_id, 'user_current_subscription_plan_payment_info') ) {
                    
                    $Db_upgrade = array(
                        'current_status'=>'active',
                    );
                    $updated = $wpdb->update( user_plan_status_info_db_name(), $Db_upgrade , array("ID"=>$plan_status_info) );
                    update_user_meta($user_id,'user_current_subscription_plan_payment_info',$plan_payment_info);
                    return json_encode(array('status'=>"0","message"=> "Not Canceled Plan Please Contact us" ));
                }
            }
            if(get_user_meta( $user_id, 'user_current_subscription_plan_user_status_info' , true )){
                 if ( ! delete_user_meta($user_id, 'user_current_subscription_plan_user_status_info') ) {
                     
                    $Db_upgrade = array(
                        'current_status'=>'active',
                    );
                    $updated = $wpdb->update( user_plan_status_info_db_name(), $Db_upgrade , array("ID"=>$plan_status_info) );
                    update_user_meta($user_id,'user_current_subscription_plan_user_status_info',$plan_status_info);
                    return json_encode(array('status'=>"0","message"=> "Not Canceled Plan Please Contact us" ));
                    
                }
            }
            
            
             
            return json_encode(array('status'=>"1","message"=> "OK CANCELED ","url" => site_url()."/user/subscription.php"  ));
}


function is_user_have_subscription_plan($user_id){
    global $wpdb;
    $current_user_payment_complete = $wpdb->get_results( 
                       "SELECT * FROM `".user_plan_status_info_db_name()."` WHERE `user_id` = $user_id AND `current_status` = \"active\" ",
                       ARRAY_A
              );
              
              if(count($current_user_payment_complete)>=1){
                 return true;
              }else{
                  return false;
              }
}

function is_user_have_subscription_plan_isFREE($user_id){
    global $wpdb;
    $current_user_payment_complete = $wpdb->get_results( 
                       "SELECT * FROM `".user_plan_status_info_db_name()."` WHERE `user_id` = $user_id AND `current_status` = \"active\" ",
                       ARRAY_A
              );
              
               if(count($current_user_payment_complete)>=1){
                 $plan_type = $current_user_payment_complete[0]['plan_type_id'];
                 
                 if($plan_type == 4){
                     return true;
                 }
                 else {
                     return false;
                 }
              }else{
                  return false;
              }
}
function is_user_subscription_plan_payment_complete($user_id){
    global $wpdb;
    $current_user_payment_complete = $wpdb->get_results( 
                       "SELECT * FROM `".user_plan_status_info_db_name()."` WHERE `user_id` = $user_id AND `current_status` = \"active\" AND `is_payment_complete` = 1 ",
                       ARRAY_A
              );
              
              if(count($current_user_payment_complete)>=1){
                    return true;
              }else{
                    return false;
              }
}
function is_user_subscription_plan_is_instalment($user_id){
    global $wpdb;
    $current_user_payment_complete = $wpdb->get_results( 
                       "SELECT * FROM `".user_plan_status_info_db_name()."` WHERE `user_id` = $user_id AND `current_status` = \"active\" AND `is_installment` = 1",
                       ARRAY_A
              );
              
              if(count($current_user_payment_complete)>=1){
                    return true;
              }else{
                    return false;
              }
}

function get_user_subscription_status($user_id){
    global $wpdb;
    $current_user_all_status = $wpdb->get_results( 
                       "SELECT * FROM `".user_plan_status_info_db_name()."` WHERE `user_id` = $user_id ",
                       ARRAY_A
              );
              
    return  $current_user_all_status;       
}
function get_user_subscription_payment($user_id){
    global $wpdb;
    $current_user_payment = $wpdb->get_results( 
                       "SELECT * FROM `".user_plan_payment_info_db_name()."` WHERE `user_id` = $user_id ",
                       ARRAY_A
              );
              
      return $current_user_payment;
}
function get_user_current_subscription_info($user_id){
    global $wpdb;
    $plan_info = get_user_meta( $user_id, 'user_current_subscription_plan' , true );
    $plan_payment_info = get_user_meta( $user_id, 'user_current_subscription_plan_payment_info' , true );
    $plan_status_info = get_user_meta( $user_id, 'user_current_subscription_plan_user_status_info' , true );
    $value = array();
    if(!$plan_info){
        $value['status'] = "0";
        return $value;
    }
    if(!$plan_payment_info){
        $value['status'] = "0";
        return $value;
    }
    if(!$plan_status_info){
        $value['status'] = "0";
        return $value;
    }
    
    $value['status'] = "1";
    
    $user_plan = get_a_plan($plan_info);
              
    $value['current_user_plan_info'] = serialize($user_plan[0]);
    
    $user_payment = $wpdb->get_results( 
                       "SELECT * FROM `".user_plan_payment_info_db_name()."` WHERE `user_id` = $user_id AND `ID` = $plan_payment_info",
                       ARRAY_A
              );
              
     $value['current_user_plan_pay_info'] = serialize($user_payment[0]);
     
     
      $user_plan_status = $wpdb->get_results( 
                       "SELECT * FROM `".user_plan_status_info_db_name()."` WHERE `user_id` = $user_id AND `ID` = $plan_status_info",
                       ARRAY_A
              );
              
     $value['current_user_plan_status_info'] = serialize($user_plan_status[0]);
     
     return $value;
    
}
