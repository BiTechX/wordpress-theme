<?php
include_once "../../../wp-config.php";
global $wpdb;
global $post;
// echo $wpdb->prefix;
// $val = $wpdb->prefix . "posts";
// $results =  $wpdb->get_results( "SELECT * FROM ".$val." WHERE post_type = 'courses' ", ARRAY_A );

// foreach($results as $result)
// {
//     echo $result["ID"];
//     echo "  ". $result["post_name"];
//     echo "   ". $result["post_content"];
//     echo get_post_meta($result->ID , 'wpt_course_level_id' , true);
//     echo "<br>";
// }

 $args = array(  
       'post_type' => 'courses',
       'post_status' => 'publish',
       //'posts_per_page' => 10000,
       'orderby' => 'title',
       'order' => 'ASC',
   );

   $loop = new WP_Query( $args );
     
   while ( $loop->have_posts() ) : $loop->the_post();
       echo the_title();
       echo the_content();
       echo "<a href = 'http://bitechx.com/fitprotest/wp-admin/admin.php?page=fitPro-theme-plugin-add-new-course-module&id=".get_the_ID()."'>Add Module</a>";
       echo get_post_meta($post->ID, 'fitpro_th_course_user_level', true);
   endwhile;

   wp_reset_postdata();

?>