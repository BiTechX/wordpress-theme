<?php 

function FITPRO_THEME_BTX_fun_new_plan_add_admin_url(){
    $url = site_url()."/wp-json/fitpro/v1/plan/admin/addPlan";
    return $url;
}
add_action( 'rest_api_init', 'FITPRO_THEME_BTX_fun_new_plan_add_admin_api_make' );
function FITPRO_THEME_BTX_fun_new_plan_add_admin_api_make(){
    register_rest_route( 'fitpro/v1', '/plan/admin/addPlan', array(
        'methods' =>'post',
        'callback' => 'new_plan_add_admin_function',
        
        
        'args' => array(
          
          "plan_type"=>array(
                    "type"=>"string",
                    'required' => true,
                ),
        
            "plan_title"=>array(
                    "type"=>"string",
                    'required' => true,
                ),
            "plan_status"=>array(
                    "type"=>"string",
                    'required' => true,
                ),
            "plan_description"=>array(
                    "type"=>"string",
                    'required' => true,
                ),
           
            ),
            ""
      ));
}

function new_plan_add_admin_function( WP_REST_Request $request ) {
       
    global $wpdb;
    $paramaters = $request->get_params();
    try{ 
        
        $rowcount = $wpdb->get_var("SELECT COUNT(*) FROM ".plan_db_info()." ");

        if($rowcount >= 6){
            return json_encode(array('status'=> '1' ,"message"=>' You are not allow to add new plan because maximum number of plan is six . ' ));
        }
        
        $plan_type_id = "4";
        $plan_type = $paramaters['plan_type'];
        $plan_title = $paramaters['plan_title'];
        $plan_status = $paramaters['plan_status'];
        $plan_total_amount = '0';
        $plan_description = $paramaters['plan_description'];
        $plan_currencye = 'USD';
        $plan_featured ='0';
        $plan_number_of_payment = '';
        $plan_setup_fee = '';
        $plan_total_month = '';
        if($plan_type == 'ONE_TIME_PAYMENT'){
            
              $plan_type_id = "1";
              $plan_title = $paramaters['plan_title'];
              $plan_total_amount = $paramaters['plan_total_amount'];
              $plan_description = $paramaters['plan_description'];
              $plan_currencye = 'USD';
              $plan_featured ='0';
              $plan_number_of_payment = '1';
              $plan_setup_fee = '0.0';
              $plan_total_month = '';
              
        }
        else if($plan_type == 'MONTHLY'){
            
              $plan_type_id = "3";
              $plan_title = $paramaters['plan_title'];
              $plan_total_amount = $paramaters['plan_total_amount'];
              $plan_description = $paramaters['plan_description'];
              $plan_currencye = 'USD';
              $plan_featured ='0';
              $plan_number_of_payment = '1';
              $plan_setup_fee = $paramaters['plan_setup_fee'];
              $plan_total_month = '1';
             
        }
        else if($plan_type == 'INSTALMENT'){
            
              $plan_type_id = "2";
              $plan_title = $paramaters['plan_title'];
              $plan_total_amount = $paramaters['plan_total_amount'];
              $plan_description = $paramaters['plan_description'];
              $plan_currencye = 'USD';
              $plan_featured ='0';
              $plan_number_of_payment = $paramaters['plan_number_of_payment'];
              $plan_setup_fee = '0.0';
              $plan_total_month = $plan_number_of_payment;
              
              
        }
        else if($plan_type == 'FREE'){
            
              $plan_type_id = "4";
              $plan_title = $paramaters['plan_title'];
              $plan_total_amount = '0.0';
              $plan_description = $paramaters['plan_description'];
              $plan_currencye = 'USD';
              $plan_featured ='0';
              $plan_number_of_payment = '';
              $plan_setup_fee = '0.0';
              $plan_total_month = '';
             
        }
        $Db_insert = array(
            'plan_type'=>$plan_type_id,
		    'plan_title'=>$plan_title,
		    'plan_description'=>$plan_description,
		    'plan_total_cost'=>$plan_total_amount,
		    'plan_setup_fee'=>$plan_setup_fee,
		    'plan_currency'=>$plan_currencye,
		    'plan_number_payment'=>$plan_number_of_payment,
		    'plan_pay_in_month'=>$plan_total_month,
		    'plan_is_featured'=>$plan_featured,
		    'plan_status'=>$plan_status,
		   
        );
        $db =  $wpdb->insert( plan_db_info(), $Db_insert);
       
        return json_encode(array('status'=> '1' ,"message"=>$paramaters  ));
     

    }catch(Exception $e){
         return json_encode(array('status'=> '1' ,"message"=>$e->getMessage()  ));
    }
}



function FITPRO_THEME_BTX_fun_new_plan_delete_admin_url(){
    $url = site_url()."/wp-json/fitpro/v1/plan/admin/deletePlan";
    return $url;
}
add_action( 'rest_api_init', 'FITPRO_THEME_BTX_fun_new_plan_delete_admin_api_make' );
function FITPRO_THEME_BTX_fun_new_plan_delete_admin_api_make(){
    register_rest_route( 'fitpro/v1', '/plan/admin/deletePlan/(?P<id>\d+)', array(
        'methods' =>'post',
        'callback' => 'delete_plan_admin_function',
        
        
        'args' => array(
         
           
            ),
            ""
      ));
}



function delete_plan_admin_function( WP_REST_Request $request ) {
       
    global $wpdb;
    $paramaters = $request->get_params();
    try{ 
       
        
        $id = $paramaters['id'];
        $table = plan_db_info();
        $wpdb->delete( $table, array( 'id' => $id ) );
         return json_encode(array('status'=> '1' ,"message"=>'delete plan successfully'  ));
    }catch(Exception $e){
         return json_encode(array('status'=> '1' ,"message"=>$e->getMessage()  ));
    }
   
      
}



function FITPRO_THEME_BTX_fun_new_plan_add_featured_admin_url(){
    $url = site_url()."/wp-json/fitpro/v1/plan/admin/featuredPlan";
    return $url;
}
add_action( 'rest_api_init', 'FITPRO_THEME_BTX_fun_new_plan_featured_add_admin_api_make' );
function FITPRO_THEME_BTX_fun_new_plan_featured_add_admin_api_make(){
    register_rest_route( 'fitpro/v1', '/plan/admin/featuredPlan/(?P<id>\d+)', array(
        'methods' =>'post',
        'callback' => 'featuredPlan_plan_admin_function',
        
        
        'args' => array(
            ),
            ""
      ));
}


function featuredPlan_plan_admin_function( WP_REST_Request $request ) {
       
    global $wpdb;
    $paramaters = $request->get_params();
    try{ 
       
        $Db_insert = array();
        $table = plan_db_info();
        
        $result_2 = $wpdb->get_results ("
           SELECT * FROM `$table` WHERE `plan_is_featured` = 1
        ");
        if(count($result_2) >= 1){
            $id = $result_2[0]->Id;
            $Db_insert = array(
            
    		    'plan_is_featured'=>'0',
    		   
            );
            $db =  $wpdb->update($table , $Db_insert , array('id'=>$id));
        }
        
        $id = $paramaters['id'];
        
        if($id == 0){
            $Db_insert = array(
		        'plan_is_featured'=>'0',
            );
        }
        else{
            $Db_insert = array(
            
		        'plan_is_featured'=>'1',
		   
            );
        }
       
        
        $db =  $wpdb->update($table , $Db_insert , array('id'=>$id));
       
        return json_encode(array('status'=> '1' ,"message"=>$paramaters  ));
     
    }catch(Exception $e){
         return json_encode(array('status'=> '1' ,"message"=>$e->getMessage()  ));
    }
   
      
}


function FITPRO_THEME_BTX_fun_new_plan_edit_admin_url(){
    $url = site_url()."/wp-json/fitpro/v1/plan/admin/editPlan";
    return $url;
}
add_action( 'rest_api_init', 'FITPRO_THEME_BTX_fun_new_plan_edit_admin_api_make' );
function FITPRO_THEME_BTX_fun_new_plan_edit_admin_api_make(){
    register_rest_route( 'fitpro/v1', '/plan/admin/editPlan/(?P<id>\d+)', array(
        'methods' =>'post',
        'callback' => 'edit_plan_admin_function',
        
        
        'args' => array(
            "plan_type"=>array(
                        "type"=>"string",
                        'required' => true,
                    ),
            
            "plan_title"=>array(
                    "type"=>"string",
                    'required' => true,
                ),

             "plan_status"=>array(
                    "type"=>"string",
                    'required' => true,
                ),
            "plan_description"=>array(
                    "type"=>"string",
                    'required' => true,
                ),
           
           
            ),
            ""
      ));
}

function edit_plan_admin_function( WP_REST_Request $request ) {
       
    global $wpdb;
    $paramaters = $request->get_params();
    try{
        
        $id = $paramaters['id'];
        $plan_type_id = "4";
        $plan_type = $paramaters['plan_type'];
        $plan_title = $paramaters['plan_title'];
        $plan_status = $paramaters['plan_status'];
        $plan_total_amount = '0';
        $plan_description = $paramaters['plan_description'];
        $plan_currencye = 'USD';
        $plan_featured ='0';
        $plan_number_of_payment = '';
        $plan_setup_fee = '';
        $plan_total_month = '';
        if($plan_type == 'ONE_TIME_PAYMENT'){
            
              $plan_type_id = "1";
              $plan_title = $paramaters['plan_title'];
              $plan_total_amount = $paramaters['plan_total_amount'];
              $plan_description = $paramaters['plan_description'];
              $plan_currencye = 'USD';
              $plan_featured ='0';
              $plan_number_of_payment = '1';
              $plan_setup_fee = '0.0';
              $plan_total_month = '';
              
        }
        else if($plan_type == 'MONTHLY'){
            
              $plan_type_id = "3";
              $plan_title = $paramaters['plan_title'];
              $plan_total_amount = $paramaters['plan_total_amount'];
              $plan_description = $paramaters['plan_description'];
              $plan_currencye = 'USD';
              $plan_featured ='0';
              $plan_number_of_payment = '1';
              $plan_setup_fee = $paramaters['plan_setup_fee'];
              $plan_total_month = '1';
             
        }
        else if($plan_type == 'INSTALMENT'){
            
              $plan_type_id = "2";
              $plan_title = $paramaters['plan_title'];
              $plan_total_amount = $paramaters['plan_total_amount'];
              $plan_description = $paramaters['plan_description'];
              $plan_currencye = 'USD';
              $plan_featured ='0';
              $plan_number_of_payment = $paramaters['plan_number_of_payment'];
              $plan_setup_fee = '0.0';
              $plan_total_month = $plan_number_of_payment;
              
              
        }
        else if($plan_type == 'FREE'){
            
              $plan_type_id = "4";
              $plan_title = $paramaters['plan_title'];
              $plan_total_amount = '0.0';
              $plan_description = $paramaters['plan_description'];
              $plan_currencye = 'USD';
              $plan_featured ='0';
              $plan_number_of_payment = '';
              $plan_setup_fee = '0.0';
              $plan_total_month = '';
             
        }
        $Db_insert = array(
            'plan_type'=>$plan_type_id,
		    'plan_title'=>$plan_title,
		    'plan_description'=>$plan_description,
		    'plan_total_cost'=>$plan_total_amount,
		    'plan_setup_fee'=>$plan_setup_fee,
		    'plan_currency'=>$plan_currencye,
		    'plan_number_payment'=>$plan_number_of_payment,
		    'plan_pay_in_month'=>$plan_total_month,
		    'plan_is_featured'=>$plan_featured,
		    'plan_status'=>$plan_status,
		   
        );
        $table = plan_db_info();
        $db =  $wpdb->update($table , $Db_insert , array('id'=>$id));


        return json_encode(array('status'=> '1' ,"message"=>$db  ));
     

    }catch(Exception $e){
         return json_encode(array('status'=> '1' ,"message"=>$e->getMessage()  ));
    }
   
        
}


function FITPRO_THEME_BTX_fun_plan_paypal_payment_user_url(){
    $url = site_url()."/wp-json/fitpro/v1/plan/user/paypal/payment";
    return $url;
}
add_action( 'rest_api_init', 'FITPRO_THEME_BTX_fun_plan_paypal_payment_user_api_make' );
function FITPRO_THEME_BTX_fun_plan_paypal_payment_user_api_make(){
    register_rest_route( 'fitpro/v1', '/plan/user/paypal/payment', array(
        'methods' =>'post',
        'callback' => 'plan_paypal_payment_user_function',
        
        
        'args' => array(
          
            "plan_id"=>array(
                    "type"=>"string",
                    'required' => true,
                ),
        
            "user_id"=>array(
                    "type"=>"string",
                    'required' => true,
                ),
            "user_plan_add"=>array(
                    "type"=>"string",
                    'required' => true,
                ),    
            
            ),
            
            ""
      ));
}

function plan_paypal_payment_user_function( WP_REST_Request $request ) {
       
    global $wpdb;
    
    $paramaters = $request->get_params();
    try{ 
        session_start();
        $plan_ID = $paramaters['plan_id'];
        $user_ID = $paramaters['user_id'];
                
        $user_plan_add =  $paramaters['user_plan_add'];
        
        
        
        $api_key = get_option('fitpro_paypal_api');
        
        $apiContext = null;

        
        if(isset($api_key['mode'])){
            
            if($api_key['mode'] == 'live'){
                
                $apiContext = new \PayPal\Rest\ApiContext(
                new \PayPal\Auth\OAuthTokenCredential(
                       $api_key['paypal_client_live']."" ,     // ClientID
                       $api_key['paypal_secret_live'].""       // ClientSecret
                    )
                );
        
                 $apiContext->setConfig(
                        array(
                            'mode' => 'live',
                            'log.LogEnabled' => true,
                            'log.FileName' => 'PayPal.log',
                            'log.LogLevel' => 'DEBUG'
                            )
                        );
                        
            }
            else{
                $apiContext = new \PayPal\Rest\ApiContext(
                new \PayPal\Auth\OAuthTokenCredential(
                       $api_key['paypal_client_sandbox'].'' ,     // ClientID
                       $api_key['paypal_secret_sandbox'].''      // ClientSecret
                    )
                );
                 $apiContext->setConfig(
                        array(
                            'mode' => 'sandbox',
                            'log.LogEnabled' => true,
                            'log.FileName' => 'PayPal.log',
                            'log.LogLevel' => 'DEBUG'
                            )
                        );
            }
        }else{
            return json_encode(array('statue'=>"0","message"=> "paypal error find in api"  ));
        }
        
        
        $result = get_a_plan($plan_ID);
        if(count($result) <= 0){
            return json_encode(array('status'=> '0' ,"message"=>"Please select proper plan."  ));
        }
        $total = $result[0]->plan_total_cost  + $result[0]->plan_setup_fee ;
        $payer = new \PayPal\Api\Payer();
        $payer->setPaymentMethod('paypal');
        
        $amount = new \PayPal\Api\Amount();
        $amount->setTotal($total."");
        $amount->setCurrency('USD');
        
        $transaction = new \PayPal\Api\Transaction();
        $transaction->setAmount($amount);
        
        $returnUrl = site_url()."/user/checkout_complete.php?plan_id=".$plan_ID."&paymentType=subscriptionPlan&payment=paypal&success=true&userId=".$user_ID;
        $cancelUrl = site_url()."/user/checkout_complete.php?plan_id=".$plan_ID."&paymentType=subscriptionPlan&payment=paypal&success=false&userId=".$user_ID;
        
        $redirectUrls = new \PayPal\Api\RedirectUrls();
        $redirectUrls->setReturnUrl($returnUrl)
            ->setCancelUrl($cancelUrl);
            
        $InputFields = new \PayPal\Api\InputFields();
        $InputFields->setNoShipping(1);
        $WebProfile = new \PayPal\Api\WebProfile();
        $WebProfile->setName( " Fit Pro PayPal Account ".uniqid() )->setInputFields($InputFields);
        $WebProfileid = $WebProfile->create($apiContext)->getId();
        
        $payment = new \PayPal\Api\Payment();
        $payment->setExperienceProfileId( $WebProfileid );
        $payment->setIntent('sale')
            ->setPayer($payer)
            ->setTransactions(array($transaction))
            ->setRedirectUrls($redirectUrls);
            
        $payment->create($apiContext);
        
        $_SESSION['USER_PAYMENT_SESSION'] = json_encode(array('status'=>"1","url"=>$payment->getApprovalLink() ,'paymentType'=>'subscriptionPlan' ,"user_plan_add" => $user_plan_add, 'plan_info'=>$result[0] ,'total_amount'=>$total,'user_id'=>$user_ID ));
        return json_encode(array('status'=>"1","message"=> "find the url","url"=>$payment->getApprovalLink()  ));
        
    }catch(Exception $e){
         return json_encode(array('status'=> '0' ,"message"=>$e->getMessage()  ));
    }
}








function FITPRO_THEME_BTX_fun_plan_stripe_payment_user_url(){
    $url = site_url()."/wp-json/fitpro/v1/plan/user/stripe/payment";
    return $url;
}
add_action( 'rest_api_init', 'FITPRO_THEME_BTX_fun_plan_stripe_payment_user_api_make' );
function FITPRO_THEME_BTX_fun_plan_stripe_payment_user_api_make(){
    register_rest_route( 'fitpro/v1', '/plan/user/stripe/payment', array(
        'methods' =>'post',
        'callback' => 'plan_stripe_payment_user_function',
        
        
        'args' => array(
            
            "name"=>array(
                    "type"=>"string",
                    'required' => true,
                ),
            "address_country"=>array(
                    "type"=>"string",
                    'required' => true,
                ),
            "address_city"=>array(
                    "type"=>"string",
                    'required' => true,
                ),
            "address_line1"=>array(
                    "type"=>"string",
                    'required' => true,
                ),    
          
           "address_zip"=>array(
                    "type"=>"string",
                    'required' => true,
                ),
            "address_state"=>array(
                    "type"=>"string",
                    'required' => true,
                ),
            "card_number"=>array(
                    "type"=>"string",
                    'required' => true,
                ), 
                
            "exp_month"=>array(
                    "type"=>"string",
                    'required' => true,
                ),
            "exp_year"=>array(
                    "type"=>"string",
                    'required' => true,
                ), 
            "cvc"=>array(
                    "type"=>"string",
                    'required' => true,
                ),
            
            "plan_id"=>array(
                    "type"=>"string",
                    'required' => true,
                ),
        
            "user_id"=>array(
                    "type"=>"string",
                    'required' => true,
                ),
            "user_plan_add"=>array(
                    "type"=>"string",
                    'required' => true,
                ),
            ),
            ""
      ));
}

function plan_stripe_payment_user_function( WP_REST_Request $request ) {
       
    global $wpdb;
    $paramaters = $request->get_params();
    try{ 
  
        
  
        $name =  $paramaters['name'];
        $address_country =  $paramaters['address_country'];
        $address_city =  $paramaters['address_city'];
        $address_state =  $paramaters['address_state'];
        $address_line1 =  $paramaters['address_line1'];
        $address_zip =  $paramaters['address_zip'];
        $card_number =  $paramaters['card_number'];
        $exp_month =  $paramaters['exp_month'];
        $exp_year =  $paramaters['exp_year'];
        
        $cvc =  $paramaters['cvc'];
        $plan_id =  $paramaters['plan_id'];
        $user_id =  $paramaters['user_id'];
        $result = get_a_plan($plan_id);
        $total_amount = $result[0]->plan_total_cost  + $result[0]->plan_setup_fee ;
        $user_Info = get_userdata( $user_id );
        $user_email = $user_Info->user_email;
        
        
        $user_plan_add =  $paramaters['user_plan_add'];
        if($user_plan_add == 'upgrade'){
             $value = json_decode( user_canceled_subscription_plan($user_id),true );
            
            if($value['status'] == 0){
                 return  json_encode(array('statue'=>"0","message"=> "Not Canceled Plan Please Contact us" ,"url"=>site_url()."/user/subscription.php"  ));
            }
        }
        
        
        $api_key = get_option('fitpro_stripe_api');
        $stripe = [
                "secret_key"      => $api_key['Secret_key'],
                "publishable_key" => $api_key['Publishable_key'],
        ];
         \Stripe\Stripe::setApiKey($stripe['secret_key']);
          $value_Stripe_token = \Stripe\Token::create([
              "card" => [
                "name"=> $name,
                "address_city"=> $address_city,
                "address_state"=> $address_state,
                "address_country"=> $address_country,
                "address_line1" =>$address_line1 ,
                "address_zip"=>$address_zip,
                "number" => $card_number,
                "exp_month" => $exp_month,
                "exp_year" => $exp_year,
                "cvc" => $cvc,
                
              ]
            ]);
            
            $value_token_get =$value_Stripe_token->id;
            
              $value_Stripe_customer = \Stripe\Customer::create([
              'email' => $user_email,
              "description" => "Fit Pro Subscription Plan Buy ".$user_email,
              'source'  => $value_token_get,
              "metadata"=> [
                    ]
            ]);
            
            $value_customer_get = $value_Stripe_customer->id;
             
            $value_Stripe_charge = \Stripe\Charge::create([
                'customer' => $value_customer_get,
                'amount'   => $total_amount * 100,
                'currency' => 'usd',
                'receipt_email'=>$user_email,
                "metadata"=> [
                    
                    ]
            ]);
            
            
            $obj = $value_Stripe_charge;
            $plan_type_id = $result[0]->plan_type;
            $payment_method = 'STRIPE';
            $currency = "USD";
            $payment_return_value = serialize($obj);
            $transaction_ID = $obj['balance_transaction'];
            $user_payment_id = set_user_subscription_plan_payment($user_id , $plan_id, $plan_type_id , $total_amount , $currency ,$payment_return_value , $payment_method ,$transaction_ID);
                        
            $this_insert = $user_payment_id;  
            
            $status_id = set_user_status_subscription_plan($user_id , $plan_id, $plan_type_id , $user_payment_id );
            
            
             $card = get_user_meta( $user_id, 'user_credit_card_info' , true );
                            if(!$card){
                                $card_Info =  array(
                                    array(
                                        "name"=> "",
                                        "address_city"=> '',
                                        "address_state"=> '',
                                        "address_country"=> '',
                                        "address_line1" =>"" ,
                                        "address_zip"=>'',
                                        "number" => '',
                                        "exp_month" => '',
                                        "exp_year" => '',
                                        "cvc" => '',
                                    ),
                                );
                                update_user_meta($user_id,'user_credit_card_info',$card_Info);
                            }
                            
                            $card = get_user_meta( $user_id, 'user_credit_card_info' , true );
                            
                            $card_Info =  array(
                               "name"=> $name,
                                "address_city"=> $address_city,
                                "address_country"=> $address_country,
                                "address_state"=> $address_state,
                                "address_line1" =>$address_line1 ,
                                "address_zip"=>$address_zip,
                                "number" => $card_number,
                                "exp_month" => $exp_month,
                                "exp_year" => $exp_year,
                                "cvc" => $cvc,
                                );
                           
                            if(!in_array($card_Info, $card)){
                                 array_push($card,$card_Info);
                                 update_user_meta($user_id,'user_credit_card_info',$card);
                            }  
                            
             $mail = WP_Mail::init()
                            ->headers([
                                    "From: Brandon Hofer <brandon.hofer@gmail.com>",
                                    "Content-type: text/html; charset=iso-8859-1",
                                ])
                            ->to($user_email)
                            ->subject('{{name}} subscription plan fit fro')
                            ->template(FITPRO_CONTROLLER_DIR_PATH.'/lib/email_temp/after_give_payment.php', [
                                'name' => $user_Info->display_name,
                                'email' => $user_email,
                                'payment_method' => 'Credit Card',
                                'transaction_ID' =>$transaction_ID  ,
                            ])
                            ->send();
                            if(!$mail){
                                return json_encode(array('statue'=>"0","message"=> "Email not send" ));
                            }
                            
                    
            return json_encode(array('status'=>"1","message"=> "add plan" ,"url"=>site_url()."/user/subscription.php"  ));
        
    }catch(Exception $e){
         return json_encode(array('status'=> '0' ,"message"=>$e->getMessage()  ));
    }
}













function FITPRO_THEME_BTX_fun_plan_cancel_user_url(){
    $url = site_url()."/wp-json/fitpro/v1/plan/user/cancel/";
    return $url;
}
add_action( 'rest_api_init', 'FITPRO_THEME_BTX_fun_plan_cancel_user_api_make' );
function FITPRO_THEME_BTX_fun_plan_cancel_user_api_make(){
    register_rest_route( 'fitpro/v1', '/plan/user/cancel/(?P<id>\d+)', array(
        'methods' =>'post',
        'callback' => 'plan_cancel_user_function',
        
        
        'args' => array(
            
            ),
            ""
      ));
}

function plan_cancel_user_function( WP_REST_Request $request ) {
        try{
            
            $paramaters = $request->get_params();
            $user_id = $paramaters['id'];
            $user_Info = get_userdata( $user_id );
            $user_email = $user_Info->user_email;
            $value = json_decode( user_canceled_subscription_plan($user_id) ,true);
            
            if($value['status'] == 1){
                 $mail = WP_Mail::init()
                            ->headers([
                                    "From: Brandon Hofer <brandon.hofer@gmail.com>",
                                    "Content-type: text/html; charset=iso-8859-1",
                                ])
                            ->to($user_email)
                            ->subject('Fit Pro subscription plan canceled ')
                            ->template(FITPRO_CONTROLLER_DIR_PATH.'/lib/email_temp/after_plan_canceled.php', [

                            ])
                            ->send();
                if(!$mail){
                        return json_encode(array('status'=>"0","message"=> "Email not send" ));
                }
                return  json_encode(array('status'=>"1","message"=> "OK canceled plan" ));
            }else{
                return  json_encode(array('status'=>"0","message"=> "Not Canceled Plan Please Contact us" ));
            }
            
           
                 
                    
        
    }catch(Exception $e){
         return json_encode(array('status'=> '0' ,"message"=>$e->getMessage()  ));
    }
}







?>
