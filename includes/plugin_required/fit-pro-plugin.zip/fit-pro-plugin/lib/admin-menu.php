<?php
function FITPRO_THEME_BTX_fun_Add_Menu()
{
	    add_menu_page(
	        'FitPro ',
	        'FitPro ',
	        'manage_options',
	        'fitPro-themne-plugin',
	        'FITPRO_THEME_BTX_fun_intro',
	        '',
	        1
	    );
	     add_submenu_page(
	        'fitPro-themne-plugin',
	        'FitPro ',
	        'FitPro ',
	        'manage_options',
	        'fitPro-themne-plugin',
	        'FITPRO_THEME_BTX_fun_intro'
    	);
    	add_submenu_page(
	        'fitPro-themne-plugin',
	        'Theme color change',
	        'Theme color change',
	        'manage_options',
	        'fitPro-themne-plugin-color-change',
	        'FITPRO_THEME_BTX_fun_theme_color_change'
    	);
    	add_submenu_page(
	        'fitPro-themne-plugin',
	        'Course Control',
	        'Course Control',
	        'manage_options',
	        'fitPro-themne-plugin-course',
	        'FITPRO_THEME_BTX_fun_course_all'
    	);
    	add_submenu_page(
	        'admin.php',
	        '',
	        '',
	        'manage_options',
	        'fitPro-theme-plugin-add-new-course',
	        'FITPRO_THEME_BTX_fun_course_add_new'
    	);
    	add_submenu_page(
	        'admin.php',
	        '',
	        '',
	        'manage_options',
	        'fitPro-theme-plugin-add-new-course-module',
	        'FITPRO_THEME_BTX_fun_course_add_new_module'
    	);
    	add_submenu_page(
	        'admin.php',
	        '',
	        '',
	        'manage_options',
	        'fitPro-theme-plugin-add-new-module-video',
	        'FITPRO_THEME_BTX_fun_course_add_new_video'
    	);
    	add_submenu_page(
	        'admin.php',
	        '',
	        '',
	        'manage_options',
	        'fitPro-theme-plugin-all_courses',
	        'FITPRO_THEME_BTX_fun_course_all_courses'
    	);

}
add_action('admin_menu', 'FITPRO_THEME_BTX_fun_Add_Menu');

function FITPRO_THEME_BTX_fun_intro()
{
    echo "Intro";
}
function FITPRO_THEME_BTX_fun_theme_color_change()
{
    echo "Color Change";
}

function FITPRO_THEME_BTX_fun_course_all()
{
    
    $comments_count = wp_count_comments();
    echo "Comments for site <br />";
    echo "Comments in moderation: " . $comments_count->moderated . "<br />"; 
    echo "Comments approved: " . $comments_count->approved . "<br />";
    echo "Comments in Spam: " . $comments_count->spam . "<br />";
    echo "Comments in Trash: " . $comments_count->trash . "<br />";
    echo "Total Comments: " . $comments_count->total_comments . "<br />";
    
   
    $url_add_course = admin_url()."admin.php?page=fitPro-theme-plugin-add-new-course";
    $url_add_module = admin_url()."admin.php?page=fitPro-theme-plugin-add-new-course-module";
    $url_all_course = admin_url()."admin.php?page=fitPro-theme-plugin-all_courses";
    $url_add_video = admin_url()."admin.php?page=fitPro-theme-plugin-add-new-module-video";
    echo "Course Control<br>";
    echo '<a href ="'.$url_add_course.'">Add A Course</a><br>';
    echo '<a href ="'.$url_add_module.'">Add A Module</a><br>';
    echo '<a href ="'.$url_all_course.'">See all Courses</a><br>';
    echo '<a href ="'.$url_add_video.'">Add A Video</a>';
    
}
function FITPRO_THEME_BTX_fun_course_add_new()
{
   
    require_once FITPRO_CONTROLLER_DIR_PATH.'/admin/add-course.php';
}
function FITPRO_THEME_BTX_fun_course_add_new_module()
{
    require_once FITPRO_CONTROLLER_DIR_PATH.'/admin/add-module.php';
}
function FITPRO_THEME_BTX_fun_course_add_new_video()
{
    echo "ADD VIDEO FOR MODULES HERE";
}
function FITPRO_THEME_BTX_fun_course_all_courses()
{
    require_once FITPRO_CONTROLLER_DIR_PATH.'/admin/all-course.php';
}

function paypalTestIN_FitPro(){
    
    $apiContext = new \PayPal\Rest\ApiContext(
        new \PayPal\Auth\OAuthTokenCredential(
            'AcqCw5c7r278CIZEd0EOYHL57PQXgxx7Iet7EtloFILvmm84Ec69AX76j7BW3ZRIBp5Ol8MmYAyS-T2D',     // ClientID
            'EFlJdoCN_cnyNYEii5NBf9A1k-wFbrYTp_kxO0iypUN7vLNxz82PeMqnLVsIrtX7YKoiMwmz5WwoLLQ-'      // ClientSecret
        )
    );
    
    
   
}
add_action('init', 'paypalTestIN_FitPro');