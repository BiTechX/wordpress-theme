<!DOCTYPE html>
<html lang="en">
<head>
    
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.0/css/bootstrap.min.css">
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.4.0/jquery.min.js"></script>
  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.0/js/bootstrap.min.js"></script>
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.4.0/jquery.min.js"></script>

    <?php 
        wp_enqueue_media();
        
      
    ?>
</head>
<body>

<div class="container">
  <h2>Add A New Course</h2>
  <form action="javascript:void(0)" id="AddCourse">
    <div class="form-group">
      <label for="text">Title :</label>
      <input type="text" class="form-control" id="CourseTitle" placeholder="Enter Title" name="title" required>
    </div>
    <div class="form-group">
      <label for="pwd">Description or Content:</label>
      <textarea class="form-control" id="exampleFormControlTextarea1" name="content" rows="3" required></textarea>
    </div>
    <div class="form-group">
        <label for="email">Upload Image:</label>
        <input type="button" class="form-control" id="FeaturedImage" required value="Upload Image" >
        <input type="hidden" id="FeaturedImageLink" name="feturedImage" >
    </div>
    
    <div class="form-group">
        <label for="email">Course User Level:</label>
         <div class="radio">
          <label><input type="radio" name="userLevel" value="premium" checked>Premium User</label>
        </div>
        <div class="radio">
          <label><input type="radio" name="userLevel" value="free">All User</label>
        </div>
    </div>
   <?php 
   $categories  =$categories = get_terms( 'category', array(
    'orderby'    => 'count',
    'hide_empty' => 0
) );;
 
print_r($categories);
   
   ?>
    
    <button type="submit" class="btn btn-default">Submit</button>
  </form>
</div>

</body>
<script>
    
jQuery(document).ready(function($) {
        jQuery("#FeaturedImage").on("click", function() {
        var images = wp.media({
            title: "Upload Image",
            multiple: true
        }).open().on("select", function(e) {
            var uploadedImages = images.state().get("selection").first();
            console.log(uploadedImages.toJSON());
            console.log(uploadedImages.toJSON().id);
            var FileLink = uploadedImages.toJSON().id;
            jQuery("#FeaturedImageLink").val(FileLink);
           
        });
    });
});
$(document).on('submit', "#AddCourse", function(e) {
      
       var postvalue =  jQuery("#AddCourse").serialize();
       var url = "<?php echo FITPRO_THEME_BTX_fun_course_add_api_url();?>";
       console.log(postvalue);
       $.post(url,postvalue,function(response){
                  console.log(response);
                  //var jsonData = jQuery.parseJSON(response);
                  //console.log(jsonData);
        });
       
       
    
});
    
</script>
</html>
