<?php
add_shortcode( "show_frontend_featured_course", 'FITPRO_THEME_BTX_fun_show_frontend_featured_course');

function FITPRO_THEME_BTX_fun_show_frontend_featured_course(){
    ob_start();
    include_once FITPRO_CONTROLLER_DIR_PATH."/views_shortcode/featured_course_fontend.php"; 
	return  ob_get_clean();
}

add_shortcode( "show_frontend_pricing", 'FITPRO_THEME_BTX_fun_show_frontend_pricing_course');

function FITPRO_THEME_BTX_fun_show_frontend_pricing_course(){
    ob_start();
    include_once FITPRO_CONTROLLER_DIR_PATH."/views_shortcode/pricing_course_fontend.php"; 
	return  ob_get_clean();
}
