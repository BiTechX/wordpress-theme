<?php if(strlen($header)) { ?>
    <h2><?php echo $header;?></h2>
<?php } ?>


<?php if(strlen($header_actions)) { ?>
    <h3><?php echo $header_actions;?></h3>
<?php } ?>

{peepso_actions}

<?php if(strlen($header_comments)) { ?>
    <h3><?php echo $header_comments; ?></h3>
<?php } ?>

{peepso_comments}
