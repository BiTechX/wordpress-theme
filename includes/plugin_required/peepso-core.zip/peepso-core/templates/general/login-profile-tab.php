<div class="ps-alert ps-alert-primary"><?php echo __('Please login', 'peepso-core');?></div>
<?php PeepSoTemplate::exec_template('general','login');?>