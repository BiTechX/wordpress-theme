<div class="ps-stream ps-stream--placeholder">
    <div class="ps-animated-background">
        <div class="ps-background-masker ps-header-top"></div>
        <div class="ps-background-masker ps-header-left"></div>
        <div class="ps-background-masker ps-header-right"></div>
        <div class="ps-background-masker ps-header-bottom"></div>
        <div class="ps-background-masker ps-subheader-left"></div>
        <div class="ps-background-masker ps-subheader-right"></div>
        <div class="ps-background-masker ps-subheader-bottom"></div>
        <div class="ps-background-masker ps-content-top"></div>
        <div class="ps-background-masker ps-content-first-end"></div>
        <div class="ps-background-masker ps-content-second-line"></div>
        <div class="ps-background-masker ps-content-second-end"></div>
        <div class="ps-background-masker ps-content-third-line"></div>
        <div class="ps-background-masker ps-content-third-end"></div>
    </div>
</div>
