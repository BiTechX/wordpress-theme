<?php
/*
Plugin Name:  Fit Pro Theme Controller Plugin
Plugin URI:   
Description:  Fit Pro Theme controlling plugin.
Version:      1.0.0
Author:       Rafat Haque & Shariar Azad
Author URI:   
*/
//session_start();

if(!defined('ABSPATH')) {
	die;
}
if(!defined('WPINC')){
	die;
}

if(!defined("FITPRO_CONTROLLER_DIR_PATH")){
	define('FITPRO_CONTROLLER_DIR_PATH',plugin_dir_path( __FILE__ ));
}
if(!defined("FITPRO_CONTROLLER_DIR_URL")){
	define('FITPRO_CONTROLLER_DIR_URL',plugin_dir_url( __FILE__ ));
}
if(!defined("FITPRO_CONTROLLER_DIR_VERSION")){
	define('FITPRO_CONTROLLER_DIR_VERSION',"1.0.0");
}
if(!defined("FITPRO_CONTROLLER_DIR_OUR_EXT")){
	define('FITPRO_CONTROLLER_DIR_OUR_EXT',"fit_pro_th_");
}

function logged_in_user_css_control( $logged_in_css , $logged_out_css ) {
    $val ="";
    if(is_user_logged_in()){
        $val = $logged_in_css;
    }
    else{
        $val = $logged_out_css;
    }
    echo $val;
}
function data_validation($data) {
	$data = trim($data);
	$data = stripslashes($data);
	$data = htmlspecialchars($data);
	return $data;
}

function course_db_name(){
        global $wpdb;
		$value = $wpdb->prefix . 'fitPro_course_info' ;
		return $value;
}
function FITPRO_THEME_BTX_fun_course_db()
{
        $tablename = "CREATE TABLE `".course_db_name()."` (
                         `id` int(11) NOT NULL AUTO_INCREMENT,
                         `course_id` int(11) NOT NULL,
                         `view_count` int(11) NOT NULL,
                         `isFeatured` tinyint(1) NOT NULL,
                         `time` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
                         PRIMARY KEY (`id`)
                        ) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci";
        require_once( ABSPATH . 'wp-admin/includes/upgrade.php' );
        dbDelta($tablename);
}
register_activation_hook( __FILE__, 'FITPRO_THEME_BTX_fun_course_db');


function module_db_name(){
        global $wpdb;
		$value = $wpdb->prefix . 'fitPro_module_info' ;
		return $value;
}
function FITPRO_THEME_BTX_fun_module_db()
{
        $tablename = "CREATE TABLE `".course_db_name()."` (
                         `id` int(11) NOT NULL AUTO_INCREMENT,
                         `course_id` int(11) NOT NULL,
                         `module_id` int(11) NOT NULL,
                         `time` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
                         PRIMARY KEY (`id`)
                        ) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci";
        require_once( ABSPATH . 'wp-admin/includes/upgrade.php' );
        dbDelta($tablename);
}
register_activation_hook( __FILE__, 'FITPRO_THEME_BTX_fun_module_db');


function video_db_name(){
        global $wpdb;
		$value = $wpdb->prefix . 'fitPro_video_info' ;
		return $value;
}
function FITPRO_THEME_BTX_fun_video_db()
{
        $tablename = "CREATE TABLE `".video_db_name()."` (
                         `id` int(11) NOT NULL AUTO_INCREMENT,
                         `video_id` int(11) NOT NULL,
                         `module_id` int(11) NOT NULL,
                         `time` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
                         PRIMARY KEY (`id`)
                        ) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci";
        require_once( ABSPATH . 'wp-admin/includes/upgrade.php' );
        dbDelta($tablename);
}
register_activation_hook( __FILE__, 'FITPRO_THEME_BTX_fun_video_db');

function TableName_module_file()
{
	global $wpdb;
	$value = $wpdb->prefix . 'dbcontrol_module_file' ;
	return $value;
}
register_activation_hook( __FILE__, 'Dashboard_Module_File');

function Dashboard_Module_File()
{
    $tablename = TableName_module_file();
    
    $Database_Table_Sql = "CREATE TABLE `$tablename` (
                 `File_ID` varchar(10) COLLATE utf8_unicode_ci NOT NULL,
                 `Module_ID` varchar(20) COLLATE utf8_unicode_ci NOT NULL,
                 `File_Location` text COLLATE utf8_unicode_ci NOT NULL,
                 `File_Name` text COLLATE utf8_unicode_ci NOT NULL,
                 PRIMARY KEY (`File_ID`)
                ) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci";
    
    require_once( ABSPATH . 'wp-admin/includes/upgrade.php' );
	dbDelta($Database_Table_Sql);
}

function table_user_progress()
{
	global $wpdb;
	$value = $wpdb->prefix . 'fitPro_user_progress' ;
	return $value;
}
register_activation_hook( __FILE__, 'User_Progress');

function User_Progress()
{
    $tablename = table_user_progress();
    
    $Database_Table_Sql = "CREATE TABLE `$tablename` (
                             `user_id` int(11) NOT NULL,
                             `course_id` int(11) NOT NULL,
                             `module_id` int(11) NOT NULL,
                             PRIMARY KEY (`user_id`,`course_id`,`module_id`)
                            ) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci";
    
    require_once( ABSPATH . 'wp-admin/includes/upgrade.php' );
	dbDelta($Database_Table_Sql);
}



function table_subscription_info()
{
	global $wpdb;
	$value = $wpdb->prefix . 'fitpro_subscription_info' ;
	return $value;
}
register_activation_hook( __FILE__, 'FITPRO_THEME_BTX_fun_Subscription_info');

function FITPRO_THEME_BTX_fun_Subscription_info()
{
    $tablename = table_subscription_info();
    
    $Database_Table_Sql = "CREATE TABLE `$tablename` (
                             `id` int(11) NOT NULL,
                             `course_id` int(11) NOT NULL,
                             PRIMARY KEY (`id`,`course_id`)
                            ) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci";
    
    require_once( ABSPATH . 'wp-admin/includes/upgrade.php' );
	dbDelta($Database_Table_Sql);
}


function plan_db_info(){
        global $wpdb;
		$value = $wpdb->prefix . 'fitPro_all_plan_info' ;
		return $value;
}
function plan_type_db_info(){
        global $wpdb;
		$value = $wpdb->prefix . 'fitPro_all_plan_type_info' ;
		return $value;
}
function plan_meta_data_db_info(){
        global $wpdb;
		$value = $wpdb->prefix . 'fitPro_all_plan_metadata_info' ;
		return $value;
}
function FITPRO_THEME_BTX_fun_plan_info()
{

        $tablename = "CREATE TABLE `". plan_db_info()."` (
                     `Id` int(11) NOT NULL AUTO_INCREMENT,
                     `plan_type` text COLLATE utf8_unicode_ci,
                     `plan_title` text COLLATE utf8_unicode_ci,
                     `plan_description` text COLLATE utf8_unicode_ci,
                     `plan_total_cost` text COLLATE utf8_unicode_ci,
                     `plan_setup_fee` text COLLATE utf8_unicode_ci,
                     `plan_currency` text COLLATE utf8_unicode_ci,
                     `plan_number_payment` text COLLATE utf8_unicode_ci,
                     `plan_pay_in_month` text COLLATE utf8_unicode_ci,
                     `plan_is_featured` text COLLATE utf8_unicode_ci,
                     `plan_status` text COLLATE utf8_unicode_ci,
                     `plan_created_date_time` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
                     PRIMARY KEY (`Id`)
                    ) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci";
        require_once( ABSPATH . 'wp-admin/includes/upgrade.php' );
        dbDelta($tablename);
        
        $tablename = "CREATE TABLE `".plan_type_db_info()."` (
                     `ID` int(11) NOT NULL AUTO_INCREMENT,
                     `plane_type` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
                     `plane_name` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
                     `plan_created_time` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
                     PRIMARY KEY (`ID`)
                    ) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci";
        
        dbDelta($tablename);
        
        $tablename = "CREATE TABLE `".plan_meta_data_db_info()."` (
                     `ID` int(11) NOT NULL AUTO_INCREMENT,
                     `plan_id` int(11) NOT NULL,
                     `plan_type_id` int(11) NOT NULL,
                     `plan_key` text COLLATE utf8_unicode_ci,
                     `plan_key_value` text COLLATE utf8_unicode_ci,
                     `plan_meta_time` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
                     PRIMARY KEY (`ID`)
                    ) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci";
        
        dbDelta($tablename);
        $no_exists_value = get_option( 'fitpro_plugin_number_install' );
        if(get_option( 'fitpro_plugin_number_install' )){
            $val = $no_exists_value + 1;
            update_option( 'fitpro_plugin_number_install',  $val);
        }
        else{
            update_option( 'fitpro_plugin_number_install',  1);
            
            $tablename = "INSERT INTO `".plan_type_db_info()."` ( `plane_type`, `plane_name`) VALUES
                                                ( 'ONE_TIME_PAYMENT', 'ONE TIME PAYMENT'),
                                                ( 'INSTALMENT', 'INSTALMENT'),
                                                ( 'MONTHLY', 'MONTHLY'),
                                                ( 'FREE', 'FREE');";
        
        
            dbDelta($tablename);
        }
       
        
}
register_activation_hook( __FILE__, 'FITPRO_THEME_BTX_fun_plan_info');

function user_plan_payment_info_db_name(){
        global $wpdb;
		$value = $wpdb->prefix . 'fitPro_user_plan_payment_info' ;
		return $value;
}
function FITPRO_THEME_BTX_fun_user_plan_payment_info()
{

        $tablename = "CREATE TABLE `".user_plan_payment_info_db_name()."`(
                     `ID` int(11) NOT NULL AUTO_INCREMENT,
                     `user_id` int(11) NOT NULL ,
                     `plan_id` int(11) NOT NULL,
                     `plan_type_id` int(11) NOT NULL,
                     `payment_method` text COLLATE utf8_unicode_ci,
                     `total_amount` text COLLATE utf8_unicode_ci,
                     `currency` text COLLATE utf8_unicode_ci,
                     `payment_return_value` text COLLATE utf8_unicode_ci,
                     `transaction_ID` text COLLATE utf8_unicode_ci,
                     `payment_created_time` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
                     PRIMARY KEY (`ID`)
                    ) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci";
        require_once( ABSPATH . 'wp-admin/includes/upgrade.php' );
        dbDelta($tablename);
        
        
        
}
register_activation_hook( __FILE__, 'FITPRO_THEME_BTX_fun_user_plan_payment_info');


function user_plan_status_info_db_name(){
        global $wpdb;
		$value = $wpdb->prefix . 'fitPro_user_plan_currrent_status_info' ;
		return $value;
}
function FITPRO_THEME_BTX_fun_user_plan_currrent_status_info()
{

        $tablename = "CREATE TABLE `".user_plan_status_info_db_name()."` (
                     `ID` int(11) NOT NULL AUTO_INCREMENT,
                     `user_id` int(11) NOT NULL,
                     `plan_id` int(11) NOT NULL,
                     `plan_type_id` int(11) NOT NULL,
                     `last_payment_id` int(11) NOT NULL,
                     `is_installment` tinyint(1) DEFAULT NULL,
                     `previous_installment_user_plan_id` int(11) DEFAULT NULL,
                     `is_installment_pay_finish` tinyint(1) DEFAULT NULL,
                     `current_installment_pay_running` int(11) DEFAULT NULL,
                     `current_status` text COLLATE utf8_unicode_ci,
                     `is_payment_complete` tinyint(1) DEFAULT NULL,
                     `starting_date` text COLLATE utf8_unicode_ci,
                     `expiry_date` text COLLATE utf8_unicode_ci,
                     `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
                     PRIMARY KEY (`ID`)
                    ) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci";
        require_once( ABSPATH . 'wp-admin/includes/upgrade.php' );
        dbDelta($tablename);

        
        
}
register_activation_hook( __FILE__, 'FITPRO_THEME_BTX_fun_user_plan_currrent_status_info');


function chat_message_db_name(){
        global $wpdb;
		$value = $wpdb->prefix . 'fitPro_chat_message' ;
		return $value;
}

function FITPRO_THEME_BTX_fun_user_chat_message_add()
{

        $tablename = "CREATE TABLE `".chat_message_db_name()."` (
                     `ID` int(11) NOT NULL AUTO_INCREMENT,
                     `sender_id` int(11) NOT NULL,
                     `recever_id` int(11) NOT NULL,
                     `message` longtext COLLATE utf8_unicode_ci NOT NULL,
                     `is_view_sender` tinyint(1) NOT NULL,
                     `is_view_reciver` tinyint(1) NOT NULL,
                     `trash_sender` tinyint(1) NOT NULL,
                     `trash_reciver` tinyint(1) NOT NULL,
                     `sent_time` text COLLATE utf8_unicode_ci NOT NULL,
                     `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
                     PRIMARY KEY (`ID`)
                    ) ENGINE=InnoDB AUTO_INCREMENT=125 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci";
                    
        require_once( ABSPATH . 'wp-admin/includes/upgrade.php' );
        dbDelta($tablename);

        
        
}
register_activation_hook( __FILE__, 'FITPRO_THEME_BTX_fun_user_chat_message_add');







function FITPRO_THEME_BTX_fun_stripe_api()
{
       add_option('fitpro_stripe_api',"");
}
register_activation_hook( __FILE__, 'FITPRO_THEME_BTX_fun_stripe_api');

function FITPRO_THEME_BTX_fun_paypal_api()
{
        add_option('fitpro_paypal_api',"");
}
register_activation_hook( __FILE__, 'FITPRO_THEME_BTX_fun_paypal_api');



//extra function

function get_all_plan(){
    global $wpdb;

    $tableName_1 = plan_db_info();
    $tableName_2 = plan_type_db_info();
    
    $results = $wpdb->get_results ( "
       SELECT * FROM `".$tableName_1."`
       INNER JOIN `".$tableName_2."`
       ON `".$tableName_1."`.`plan_type` = `".$tableName_2."`.`ID`
       WHERE `d43_fitPro_all_plan_info`.`plan_status` = 'publish'
    ");
    return $results;
}
function get_a_plan($id){
    global $wpdb;

    $tableName_1 = plan_db_info();
    $tableName_2 = plan_type_db_info();
    
    $results = $wpdb->get_results ( "
       SELECT * FROM `".$tableName_1."`
       INNER JOIN `".$tableName_2."`
       ON `".$tableName_1."`.`plan_type` = `".$tableName_2."`.`ID`
       WHERE `".$tableName_1."`.`Id` = ".$id."
    ");
    return $results;
}

function wpdocs_add_dashboard_widgets() {
   // wp_add_dashboard_widget( 'dashboard_widget', 'Example Dashboard Widget', 'dashboard_widget_function' );
   add_meta_box( 'dashboard_admin_link', 'Admin Go To  Link', 'dashboard_widget_function', 'dashboard', 'advanced', 'high' );
}
add_action( 'wp_dashboard_setup', 'wpdocs_add_dashboard_widgets' );
 
function dashboard_widget_function() {
    echo '
    	    <h2>Welcome to WordPress!</h2>
			<p class="about-description">We’ve assembled some links to get you started:</p>
    	<center>
			<div>
                <a class="button button-primary button-hero load-customize hide-if-no-customize" href="'. site_url()."/admin/".'">Go To Main Dashboard</a>
            </div>
        </center>       
         <br> 
                ';
}




add_action( 'admin_footer', 'custom_dashboard_widget_for_admin_link' );
function custom_dashboard_widget_for_admin_link() {
	// Bail if not viewing the main dashboard page
	if ( get_current_screen()->base !== 'dashboard' ) {
		return;
	}
	?>


	<div id="custom-id" class="welcome-panel" style="display: none;">
		<div class="welcome-panel-content">
			<h2>Welcome to WordPress!</h2>
			<p class="about-description">We’ve assembled some links to get you started:</p>
			<center>
			    <div>
                    <a class="button button-primary button-hero load-customize hide-if-no-customize" href="<?php echo site_url()."/admin/";?>">Go To Main Dashboard</a>
                </div>
            </center>
			<br>
			<!--
			<div class="welcome-panel-column-container">
				<div class="welcome-panel-column">
					<h3>Get Started</h3>
					<a class="button button-primary button-hero load-customize hide-if-no-customize" href="http://localhost:8888/uw-website/wp-admin/customize.php">Customize Your Site</a>
					<a class="button button-primary button-hero hide-if-customize" href="http://localhost:8888/uw-website/wp-admin/themes.php">Customize Your Site</a>
					<p class="hide-if-no-customize">or, <a href="http://localhost:8888/uw-website/wp-admin/themes.php">change your theme completely</a></p>
				</div>
				<div class="welcome-panel-column">
					<h3>Next Steps</h3>
					<ul>
						<li><a href="http://localhost:8888/uw-website/wp-admin/post.php?post=2557&amp;action=edit" class="welcome-icon welcome-edit-page">Edit your front page</a></li>
						<li><a href="http://localhost:8888/uw-website/wp-admin/post-new.php?post_type=page" class="welcome-icon welcome-add-page">Add additional pages</a></li>
						<li><a href="http://localhost:8888/uw-website/wp-admin/post-new.php" class="welcome-icon welcome-write-blog">Add a blog post</a></li>
						<li><a href="http://localhost:8888/uw-website/" class="welcome-icon welcome-view-site">View your site</a></li>
					</ul>
				</div>
				<div class="welcome-panel-column welcome-panel-last">
					<h3>More Actions</h3>
					<ul>
						<li><div class="welcome-icon welcome-widgets-menus">Manage <a href="http://localhost:8888/uw-website/wp-admin/widgets.php">widgets</a> or <a href="http://localhost:8888/uw-website/wp-admin/nav-menus.php">menus</a></div></li>
						<li><a href="http://localhost:8888/uw-website/wp-admin/options-discussion.php" class="welcome-icon welcome-comments">Turn comments on or off</a></li>
						<li><a href="https://codex.wordpress.org/First_Steps_With_WordPress" class="welcome-icon welcome-learn-more">Learn more about getting started</a></li>
					</ul>
				</div>
			</div>
			
			-->
		</div>
		
		
	</div>
	

	<script>
		jQuery(document).ready(function($) {
			$('#welcome-panel').after($('#custom-id').show());
		});
	</script>

<?php }





/*
add_action( 'init', 'is_user_current_active' );
function is_user_current_active() {
    if(is_user_logged_in()){
        $user_id = get_current_user_id();
        
    }
}
*/




//this is menu of all admin section 
require_once FITPRO_CONTROLLER_DIR_PATH.'/lib/WP_Mail/src/WP_Mail.php';
require_once FITPRO_CONTROLLER_DIR_PATH.'/lib/extra-func/extra_function.php';
require_once FITPRO_CONTROLLER_DIR_PATH.'/lib/stripe-php/init.php';
require_once FITPRO_CONTROLLER_DIR_PATH  . '/lib/PayPal-PHP-SDK/autoload.php';
require_once FITPRO_CONTROLLER_DIR_PATH.'/lib/admin-menu.php';
require_once FITPRO_CONTROLLER_DIR_PATH.'/lib/meta-box.php';
require_once FITPRO_CONTROLLER_DIR_PATH.'/lib/api-call.php';
require_once FITPRO_CONTROLLER_DIR_PATH.'/lib/short_code.php';

