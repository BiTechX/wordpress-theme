<div class="ps-stream-repost">	
	<div class="ps-stream-attachment">
		<div class="ps-alert ps-alert-danger"><?php _e('The user has decided to keep this post private.', 'peepso-core'); ?></div>
	</div>
</div>