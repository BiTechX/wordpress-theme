import hashtag from './hashtag';
import mention from './mention';
import profileCompleteness from './profile-completeness';

document.addEventListener( 'DOMContentLoaded', () => {
	hashtag.init();
	mention.init();
	profileCompleteness.init();
} );
