<div class="ps-notice">
    <?php echo $message;?>
</div>
