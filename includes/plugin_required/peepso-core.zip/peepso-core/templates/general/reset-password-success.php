<div class="reset-gap ps-clearfix">
	<form id="recoverpasswordform" name="recoverpasswordform" action="<?php PeepSo::get_page('activity'); ?>" method="post" class="ps-form">
		<p><?php _e('Your password has been changed. You can sign in now.', 'peepso-core'); ?></p>
	</form>
</div>
