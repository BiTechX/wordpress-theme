<?php

require_once FITPRO_CONTROLLER_DIR_PATH.'/lib/extra-func/subscription_plan_func.php';

function is_course_added_to_list($course,$user_ID)
{
    global $wpdb;
    
    $results = $wpdb->get_results( "SELECT course_id FROM ".table_subscription_info()." WHERE id = ".$user_ID."", ARRAY_A );
    
    foreach($results as $result)
    {
        if($result['course_id'] == $course)
            return true;
    }
    return false;
}

function user_access_of_course($course,$user_ID)
{
    global $wpdb;
    
    $plan_payment_info = get_user_meta( $user_ID, 'user_current_subscription_plan_payment_info' , true );
    
    if(empty($plan_payment_info))
    {
        return false;
    }
    
    $user_payment = $wpdb->get_results( 
                       "SELECT * FROM `".user_plan_payment_info_db_name()."` WHERE `user_id` = $user_ID AND `ID` = $plan_payment_info",
                       ARRAY_A
              );
    
    $levels = get_post_meta($course,'fitpro_th_course_user_level',true);
    
    $levels = explode("," , $levels);
    
    if(in_array($user_payment[0]['plan_id'] , $levels))
        return true;
    else
        return false;
}

?>