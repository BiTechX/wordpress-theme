<div class="ps-members-item-buttons" data-user-id="<?php echo $user_id; ?>">
	<?php echo $member_buttons; ?>
</div>
