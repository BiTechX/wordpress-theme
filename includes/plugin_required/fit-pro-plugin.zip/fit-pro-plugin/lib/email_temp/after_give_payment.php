<h3>You Buy a plan from fit pro </h3><br>

<p>
  <strong>Name:</strong><?= $name ?>
</p>

<p>
  <strong>Email:</strong>
  <a href="mailto:<?= $email ?>"><?= $email ?></a>
</p>
    
<p>
 <strong>Transaction ID:</strong>
   <strong><?= $transaction_ID ?></strong>
</p>
<p>
 <strong>Payment Method:</strong>
   <strong><?= $payment_method ?></strong>
</p>