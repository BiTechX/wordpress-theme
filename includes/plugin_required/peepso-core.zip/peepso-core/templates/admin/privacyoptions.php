<a href="#" class="button ps-js-reset-privacy"><?php _e('Reset users\' privacy settings to default','peepso-core');?></a>
