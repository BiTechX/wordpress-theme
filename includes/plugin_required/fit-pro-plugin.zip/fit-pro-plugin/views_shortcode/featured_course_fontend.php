<?php 
    
?>
    <div class="et_pb_section et_pb_section_15 flip-card-section et_pb_with_background et_section_regular" style="background-color:transparent;">

        <div class="et_pb_row" style="max-width:600px;margin-bottom:20px">
            <div class="et_pb_column et_pb_column_4_4    et_pb_css_mix_blend_mode_passthrough et-last-child">

                <div class="et_pb_module et_pb_text  et_pb_bg_layout_light  et_pb_text_align_left">

                    <div class="et_pb_text_inner">
                        <h1 class="primary-color1" style="text-align: center;">Here's What You'll Learn...</h1>
                        <p class="primary-color1" style="text-align: center;">The Proven 6-Step Formula for Long Term Business Success...</p>
                    <!--    <p class="primary-color1" style="text-align: center;">Or, you can invest yourself in learning the business building principles and strategies that Erin and Jason and so many others have committed themselves to.</p>
                        <p class="primary-color1" style="text-align: center;"><strong>By leveraging the proven 6-step process, you can build a thriving coaching business in 6 months or less without the never ending struggle and the revenue roller coaster.</strong></p>-->
                    </div>
                </div>
                <!-- .et_pb_text -->
            </div>
            <!-- .et_pb_column -->

        </div>
        <!-- .et_pb_row -->
        <div class="et_pb_row flip-card">
            <div class="et_pb_column et_pb_column_4_4  flip-card-inner  et_pb_css_mix_blend_mode_passthrough et-last-child">

                <div class="et_pb_module et_pb_text  flip-card-front secondary-color1-overlay et_pb_bg_layout_light  et_pb_text_align_left" style="background:url('https://fitprobizlaunch.com/wp-content/uploads/2019/05/wq.jpg');background-size:cover;">

                    <div class="et_pb_text_inner">
                        
                        <p style="text-align: center;"><img class="size-full wp-image-309 aligncenter" src="https://fitprobizlaunch.com/wp-content/uploads/2019/05/Vector-Smart-Object11.png"></p>
                        <h5 class="white" style="text-align: center;">MODULE 1</h5>
                        <h6 class="white" style="text-align: center;">STREAMLINED BUSINESS PLANNINNG</h6>
                    </div>
                </div>
                <!-- .et_pb_text -->
                <div class="et_pb_module et_pb_text  flip-card-back primary-color2-background primary-color1 et_pb_bg_layout_light  et_pb_text_align_left">

                    <div class="et_pb_text_inner">
                        <p>Fitness Business Planning and why it's absolutely essential for your success.</p>
                    </div>
                </div>
                <!-- .et_pb_text -->
            </div>
            <!-- .et_pb_column -->

        </div>
        <!-- .et_pb_row -->
        <div class="et_pb_row flip-card">
            <div class="et_pb_column et_pb_column_4_4  flip-card-inner  et_pb_css_mix_blend_mode_passthrough et-last-child">

                <div class="et_pb_module et_pb_text  flip-card-front  primary-color1-overlay et_pb_bg_layout_light  et_pb_text_align_left" style="background:url('https://fitprobizlaunch.com/wp-content/uploads/2019/05/Background0.jpg');background-size:cover;">

                    <div class="et_pb_text_inner">
                        
                        <p style="text-align: center;"><img class="size-full wp-image-309 aligncenter" src="https://fitprobizlaunch.com/wp-content/uploads/2019/05/Vector-Smart-Objec52t.png"></p>
                       <h5 class="white" style="text-align: center;">MODULE 2</h5>
                        <h6 class="white" style="text-align: center;">CLIENT CONNECTION</h6>
                    </div>
                </div>
                <!-- .et_pb_text -->
                <div class="et_pb_module et_pb_text  flip-card-back primary-color2-background primary-color1 et_pb_bg_layout_light  et_pb_text_align_left">

                    <div class="et_pb_text_inner">
                        <p>How to create a Client Connection strategy so you can reach those who you are able to serve most powerfully.</p>
                    </div>
                </div>
                <!-- .et_pb_text -->
            </div>
            <!-- .et_pb_column -->

        </div>
        <!-- .et_pb_row -->
        <div class="et_pb_row flip-card">
            <div class="et_pb_column et_pb_column_4_4  flip-card-inner  et_pb_css_mix_blend_mode_passthrough et-last-child">

                <div class="et_pb_module et_pb_text  flip-card-front  secondary-color1-overlay et_pb_bg_layout_light  et_pb_text_align_left" style="background:url('https://fitprobizlaunch.com/wp-content/uploads/2019/05/Background.jpg');background-size:cover;">

                    <div class="et_pb_text_inner">
                        
                        <p style="text-align: center;"><img class="size-full wp-image-309 aligncenter" src="https://fitprobizlaunch.com/wp-content/uploads/2019/05/Vector-Smart-Objeeqct.png"></p>
                        <h5 class="white" style="text-align: center;">MODULE 3</h5>
                        <h6 class="white" style="text-align: center;">POWERFUL BRANDING</h6>
                    </div>
                </div>
                <!-- .et_pb_text -->
                <div class="et_pb_module et_pb_text  flip-card-back primary-color2-background primary-color1 et_pb_bg_layout_light  et_pb_text_align_left">

                    <div class="et_pb_text_inner">
                        <p>Powerful Branding and how to stand out above the noise in a crowded industry.</p>
                    </div>
                </div>
                <!-- .et_pb_text -->
            </div>
            <!-- .et_pb_column -->

        </div>
        <!-- .et_pb_row -->
        <div class="et_pb_row divider_row">
            <div class="et_pb_column et_pb_column_4_4    et_pb_css_mix_blend_mode_passthrough et-last-child">

                <div class="et_pb_module et_pb_divider et_pb_divider_0 et_pb_divider_position_ et_pb_space">
                    <div class="et_pb_divider_internal"></div>
                </div>
            </div>
            <!-- .et_pb_column -->

        </div>
        <!-- .et_pb_row -->
        <div class="et_pb_row flip-card">
            <div class="et_pb_column et_pb_column_4_4  flip-card-inner  et_pb_css_mix_blend_mode_passthrough et-last-child">

                <div class="et_pb_module et_pb_text  flip-card-front primary-color1-overlay et_pb_bg_layout_light  et_pb_text_align_left" style="background:url('https://fitprobizlaunch.com/wp-content/uploads/2019/05/Background21.jpg');background-size:cover;">

                    <div class="et_pb_text_inner">
                       
                        <p style="text-align: center;"><img class="size-full wp-image-309 aligncenter" src="https://fitprobizlaunch.com/wp-content/uploads/2019/05/Vector-Smart-Objecqwt.png"></p>
                        <h5 class="white" style="text-align: center;">MODULE 4</h5>
                        <h6 class="white" style="text-align: center;">TRANSFORMATIVE PROGRAMMING</h6>
                    </div>
                </div>
                <!-- .et_pb_text -->
                <div class="et_pb_module et_pb_text  flip-card-back primary-color2-background primary-color1 et_pb_bg_layout_light  et_pb_text_align_left">

                    <div class="et_pb_text_inner">
                        <p>Why creating Transformative Programs is the key element to lifting yourself out of the session by session model.</p>
                    </div>
                </div>
                <!-- .et_pb_text -->
            </div>
            <!-- .et_pb_column -->

        </div>
        <!-- .et_pb_row -->
        <div class="et_pb_row flip-card">
            <div class="et_pb_column et_pb_column_4_4  flip-card-inner  et_pb_css_mix_blend_mode_passthrough et-last-child">

                <div class="et_pb_module et_pb_text  flip-card-front  secondary-color1-overlay et_pb_bg_layout_light  et_pb_text_align_left" style="background:url('https://fitprobizlaunch.com/wp-content/uploads/2019/05/412.jpg');background-size:cover;">

                    <div class="et_pb_text_inner">
                       
                        <p style="text-align: center;"><img class="size-full wp-image-309 aligncenter" src="https://fitprobizlaunch.com/wp-content/uploads/2019/05/Vector-Smart-Object134.png"></p>
                        <h5 class="white" style="text-align: center;">MODULE 5</h5>
                       <h6 class="white" style="text-align: center;">VALUE DRIVEN ENROLLMENT</h6>
                    </div>
                </div>
                <!-- .et_pb_text -->
                <div class="et_pb_module et_pb_text  flip-card-back primary-color2-background primary-color1 et_pb_bg_layout_light  et_pb_text_align_left">

                    <div class="et_pb_text_inner">
                        <p>The exact formula for Value Driven Enrollment so you never have to use cheesy sales tactics ever again.</p>
                    </div>
                </div>
                <!-- .et_pb_text -->
            </div>
            <!-- .et_pb_column -->

        </div>
        <!-- .et_pb_row -->
        <div class="et_pb_row flip-card">
            <div class="et_pb_column et_pb_column_4_4  flip-card-inner  et_pb_css_mix_blend_mode_passthrough et-last-child">

                <div class="et_pb_module et_pb_text  flip-card-front primary-color1-overlay et_pb_bg_layout_light  et_pb_text_align_left" style="background:url('https://fitprobizlaunch.com/wp-content/uploads/2019/05/1.jpg');background-size:cover;">

                    <div class="et_pb_text_inner">
                        
                        <p style="text-align: center;"><img class="size-full wp-image-309 aligncenter" src="https://fitprobizlaunch.com/wp-content/uploads/2019/05/Vector-Smart-Orqbject.png"></p>
                        <h5 class="white" style="text-align: center;">MODULE 6</h5>
                        <h6 class="white" style="text-align: center;">PREDICTABLE CLIENT CREATION</h6>
                    </div>
                </div>
                <!-- .et_pb_text -->
                <div class="et_pb_module et_pb_text  flip-card-back primary-color2-background primary-color1 et_pb_bg_layout_light  et_pb_text_align_left">

                    <div class="et_pb_text_inner">
                        <p>Learn why creating a system for Predictable Client Creation is the only way to create a long term business foundation.</p>
                    </div>
                </div>
                <!-- .et_pb_text -->
            </div>
            <!-- .et_pb_column -->

        </div>
        <!-- .et_pb_row -->

    </div>