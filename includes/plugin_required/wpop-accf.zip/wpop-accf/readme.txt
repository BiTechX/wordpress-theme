=== Active Campaign & Contact Form 7 ===

Contributors: WPOperations
Tags: active campaign, conatct form 7 active campaign, cf7 active campaign, subscription list, wpoperation, cf7 integration, mailing list, cf7 mailing list
Requires at least: 4.5.0
Tested up to: 5.2
Requires PHP: 5.2
Stable tag: 1.0.5
License: GPLv2 or later
License URI: http://www.gnu.org/licenses/gpl-2.0.html

Add Contact Form 7 Data to Active Campiagn Contact lists.

== Description ==

Contact Form 7 is the most popular WordPress contact form builder and Active Campaign & Contact Form 7 developed as addon of Contact Form 7, helps to extend your subscription lists and collect unlimited leads .You can easily add your contacts in Active campaign when your  contact form is submitted.



=== Features === 

Adds subscription in "Active Campaign" through "Contact Form 7"
Option to select "Active Campaign" list ID for subscribers
Option to select "Contact Form 7" fields for "Active Campaign" list
Constant updates

== Installation ==
1. Unzip wpop-accf.zip
2. Upload all the files to the /wp-content/plugins/wpop-accf
3. Activate the plugin through the 'Plugins' menu in WordPress.
4. For customizing the plugin's settings, open "Contact Form 7"  form and go to "Active Campaign" tab

== Frequently Asked Questions ==


= Is Contact Form 7 Required? =
Yes 

= What does this plugin do? =
This plugin adds feature to "Contact Form 7" to add subscription in "Active Campaign"

= What does this plugin do? =
This plugin adds feature to "Contact Form 7" to add subscription in "Active Campaign"

= How to generate Active Campaign API credentials? =
You can follow this link 
https://help.activecampaign.com/hc/en-us/articles/207317590-Getting-started-with-the-API


== Changelog ==


= 1.0.5 =
* Added support for wordpress 5.2 

= 1.0.4 = 
*Changed API to support update existing contact list in active campaign

= 1.0.3 = 
*Minor bugs fixed

= 1.0.2 = 
*Minor Fixes

= 1.0.1 = 
*Minor Fixes

= 1.0.0 =
*Initial release

