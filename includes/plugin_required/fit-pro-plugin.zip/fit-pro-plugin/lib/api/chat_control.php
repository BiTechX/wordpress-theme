<?php


function FITPRO_THEME_BTX_fun_chat_message_add_user_url(){
    $url = site_url()."/wp-json/fitpro/v1/chat/user/add";
    return $url;
}
add_action('rest_api_init', 'FITPRO_THEME_BTX_fun_chat_message_add_user_api_make');
function FITPRO_THEME_BTX_fun_chat_message_add_user_api_make(){
    register_rest_route( 'fitpro/v1', '/chat/user/add', array(
        'methods' =>'post',
        'callback' => 'chat_message_add_user',
        
        
        'args' => array(
          
          "message"=>array(
                    "type"=>"string",
                    'required' => true,
                ),
            "sender_id"=>array(
                    "type"=>"string",
                    'required' => true,
                ),
            "reciver_id"=>array(
                    "type"=>"string",
                    'required' => true,
                ),
           
            ),
            ""
      ));
}

function chat_message_add_user( WP_REST_Request $request ) {
       
    global $wpdb;
    $paramaters = $request->get_params();
    try{ 
      
       $data = $paramaters['message'];
       $sender = $paramaters['sender_id'];
       $reciver =$paramaters['reciver_id'];
       $is_view_sender = true;
       $is_view_reciver = false;
       
        $sender_user_chat_status = get_user_meta($sender , 'user_chat_status' , true);
        $reciver_user_chat_status = get_user_meta($reciver , 'user_chat_status' ,true );
        
        
        if($reciver_user_chat_status){
            $is_view_reciver = true;
        }
        
       
        $Db_insert = array(
            'sender_id'=>$sender,
		    'recever_id'=>$reciver,
		    'message'=>stripslashes(trim($data)),
		    'is_view_sender'=>$is_view_sender,
		    'is_view_reciver'=>$is_view_reciver,
		    'trash_sender'=> false,
		    'trash_reciver'=> false,
		    'sent_time'=> strtotime("now"),
        );
        $db =  $wpdb->insert( chat_message_db_name() , $Db_insert);
        
      
        return json_encode(array('status'=> '1' ,"message"=>$sender_user_chat_status." ".$reciver_user_chat_status  ));
     

    }catch(Exception $e){
         return json_encode(array('status'=> '0' ,"message"=>$e->getMessage()  ));
    }
}


function FITPRO_THEME_BTX_fun_chat_message_trash_user_url(){
    $url = site_url()."/wp-json/fitpro/v1/chat/user/trash";
    return $url;
}
add_action( 'rest_api_init', 'FITPRO_THEME_BTX_fun_chat_message_trash_user_api_make' );
function FITPRO_THEME_BTX_fun_chat_message_trash_user_api_make(){
    register_rest_route( 'fitpro/v1', '/chat/user/trash', array(
        'methods' =>'post',
        'callback' => 'chat_message_trash_user',
        
        'args' => array(
          
            "sender_id"=>array(
                    "type"=>"string",
                    'required' => true,
                ),
            
           
            ),
            ""
      ));
}

function chat_message_trash_user( WP_REST_Request $request ) {
       
    global $wpdb;
    $paramaters = $request->get_params();
    try{ 
      
     
       $sender = $paramaters['sender_id'];
       
      /*
        $Db_update = array(
            'trash_sender'=>true,
		    'trash_sender'=>true,
        );
        $db =  $wpdb->update(chat_message_db_name(), $Db_update , array('sender_id'=>$sender));
        
      */
      
       
        $table = chat_message_db_name();
         
        $db =  $wpdb->query( 
            	$wpdb->prepare( 
            		
            		"UPDATE `$table` 
            		SET `trash_sender` = %d , `trash_reciver` = %d  
            		WHERE `sender_id`= %d  OR `recever_id`= %d  "
            		,
            	        1,1,$sender,$sender 
                    )
            );
         
         
      
        return json_encode(array('status'=> '1' ,"message"=>$db  ));
     

    }catch(Exception $e){
         return json_encode(array('status'=> '0' ,"message"=>$e->getMessage()  ));
    }
}




function FITPRO_THEME_BTX_fun_chat_view_change_url(){
    $url = site_url()."/wp-json/fitpro/v1/chat/viewchange";
    return $url;
}
add_action( 'rest_api_init', 'FITPRO_THEME_BTX_fun_chat_view_change_api_make' );
function FITPRO_THEME_BTX_fun_chat_view_change_api_make(){
    register_rest_route( 'fitpro/v1', '/chat/viewchange', array(
        'methods' =>'post',
        'callback' => 'chat_view_change',
        
        
        'args' => array(
          
         
            "sender_id"=>array(
                    "type"=>"string",
                    'required' => true,
                ),
                 "reciver_id"=>array(
                    "type"=>"string",
                    'required' => true,
                ),
                 "last_message"=>array(
                    "type"=>"string",
                    'required' => true,
                ),
            
           
            ),
            ""
      ));
}

function chat_view_change( WP_REST_Request $request ) {
       
    global $wpdb;
    $paramaters = $request->get_params();
    try{ 
    
     
       $sender_id = $paramaters['sender_id'];
       $recever_id = $paramaters['reciver_id'];
       $last_message_id = $paramaters['last_message'];
       
       
       //$updated = update_user_meta( $sender_id, 'user_chat_status', 0 );   
       
        $Db_update = array(
		    'is_view_reciver'=> true,
        );
        $db =  $wpdb->update(chat_message_db_name(), $Db_update , array('ID'=>111));
    
      
        $table = chat_message_db_name();
         
        $db =  $wpdb->query( 
            	$wpdb->prepare( 
            		
            		"UPDATE `$table` 
            		SET `is_view_reciver` = %d 
            		WHERE `sender_id`= %d  AND `recever_id`= %d  "
            		,
            	        1,$recever_id,$sender_id 
                    )
            );
         
         
      
        return json_encode(array('status'=> '1' ,"message"=>$db  ));
     

    }catch(Exception $e){
         return json_encode(array('status'=> '0' ,"message"=>$e->getMessage()  ));
    }
}


function FITPRO_THEME_BTX_fun_chat_message_count_user_url(){
    $url = site_url()."/wp-json/fitpro/v1/chat/user/messageCount";
    return $url;
}
add_action('rest_api_init', 'FITPRO_THEME_BTX_fun_chat_message_count_user_api_make');
function FITPRO_THEME_BTX_fun_chat_message_count_user_api_make(){
    register_rest_route( 'fitpro/v1', '/chat/user/messageCount', array(
        'methods' =>'post',
        'callback' => 'chat_message_count_user',
        
        
        'args' => array(
          
        
            "sender_id"=>array(
                    "type"=>"string",
                    'required' => true,
                ),
            "reciver_id"=>array(
                    "type"=>"string",
                    'required' => true,
                ),
           
            ),
            ""
      ));
}

function chat_message_count_user( WP_REST_Request $request ) {
       
    global $wpdb;
    $paramaters = $request->get_params();
    try{ 
      
       $sender = $paramaters['sender_id'];
       $reciver =$paramaters['reciver_id'];
        $results = $wpdb->get_results ( "
            SELECT * FROM `".chat_message_db_name()."` WHERE  (`sender_id` = $reciver  AND `recever_id` = $sender) OR (`sender_id` = $sender  AND `recever_id` = $reciver) 
        ");
       return json_encode(array('status'=> '1' ,"message"=>count($results)  ));
     

    }catch(Exception $e){
         return json_encode(array('status'=> '0' ,"message"=>$e->getMessage()  ));
    }
}





