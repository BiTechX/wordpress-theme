<?php


function wpt_add_courses_metaboxes() {

	add_meta_box(
		'wpt_course_level_id',
		'Course Level',
		'wpt_course_level',
		'courses',
		'side',
		'high'
	);
	
	add_meta_box(
		'wpt_course_image_id',
		'Course Level',
		'wpt_course_image',
		'courses',
		'side',
		'high'
	);

}

function FITPRO_THEME_BTX_fun_cw_post_type_courses() {
    $supports = array(
        'title', // video title
        'editor', // video description
        //'thumbnail', // course image
        //'excerpt',
        //'custom-fields', // custom fields
        //'comments', // video comments
    );
    $labels = array(
        'name' => _x('Courses', 'plural'),
        'singular_name' => _x('Course', 'singular'),
        'menu_name' => _x('Courses', 'admin menu'),
        'name_admin_bar' => _x('Courses', 'admin bar'),
        'add_new' => _x('Add Course', 'add new'),
        'add_new_item' => __('Add New Courses'),
        'new_item' => __('New Courses'),
        'edit_item' => __('Edit Courses'),
        'view_item' => __('View Courses'),
        'all_items' => __('All Courses'),
        //'search_items' => __('Search videos'),
        //'not_found' => __('No videos found.'),
    );
        $args = array(
        'supports'             => $supports,
        'labels'               => $labels,
        'public'               => true,
        'publicly_queryable'   => true,
        'query_var'            => true,
		'capability_type'      => 'page',
		'rewrite'              => array( 'slug' => 'courses' ),
		'has_archive'          => true,
		'menu_position'        => 5,
		'menu_icon'            => 'dashicons-calendar-alt',
		'register_meta_box_cb' => 'wpt_add_courses_metaboxes',
		'hierarchical' => true,
		'taxonomies' => array('category', 'post_tag')
    );
    register_post_type('courses', $args);
    flush_rewrite_rules();
}

add_action('init', 'FITPRO_THEME_BTX_fun_cw_post_type_courses');

function wpt_course_level() {

    global $post;
	$course_price = get_post_meta( $post->ID, 'fitpro_th_course_user_level', true );

	wp_nonce_field( basename( __FILE__ ), 'course_level_nonce' );

    echo $course_price."<br>";
  
	echo '<input type="radio" name="course_level" value="premium" class="widefat " required/>Premium User<br><br>';
	echo '<input type="radio" name="course_level" value="free" class="widefat">All User';
}

function wpt_course_image() {

    global $post;
	$course_price = get_post_meta( $post->ID, 'fitpro_th_course_image', true );

	wp_nonce_field( basename( __FILE__ ), 'course_image_nonce' );
  
	echo '<input type="text" name="course_url" value = '.$course_price.'>Image Link<br><br>';

}

function wpt_save_post_courses( $post_id, $post, $update ) {
    
    if ( ! isset( $_POST['course_level_nonce'] ) || ! isset( $_POST['course_image_nonce'] ) || ! wp_verify_nonce( $_POST['course_level_nonce'], basename(__FILE__) ) || ! wp_verify_nonce( $_POST['course_image_nonce'], basename(__FILE__) ) ) {
     		return $post_id;
     }
    $course_level_value =  $_POST['course_level'];
    $course_image_url = $_POST['course_url'];
    update_post_meta( $post_id, "fitpro_th_course_user_level", $course_level_value);
    update_post_meta( $post_id, "fitpro_th_course_image", $course_image_url);
}

add_action( 'save_post', 'wpt_save_post_courses', 10,3 );

function wpt_add_modules_metaboxes() {
	
	add_meta_box(
		'wpt_module_image_id',
		'Module Image',
		'wpt_module_image',
		'modules',
		'side',
		'high'
	);

}

function FITPRO_THEME_BTX_fun_cw_post_type_modules() {
    $supports = array(
        'title', // module title
        //'editor', // video description
        'thumbnail', // module image
        // 'excerpt',
        //'custom-fields', // custom fields
        //'comments', // video comments
        
    );
    $labels = array(
        'name' => _x('Modules', 'plural'),
        'singular_name' => _x('Module', 'singular'),
        'menu_name' => _x('Modules', 'admin menu'),
        'name_admin_bar' => _x('Modules', 'admin bar'),
        'add_new' => _x('Add Course', 'add new'),
        'add_new_item' => __('Add New Modules'),
        'new_item' => __('New Modules'),
        'edit_item' => __('Edit Modules'),
        'view_item' => __('View Modules'),
        'all_items' => __('All Modules'),
        //'search_items' => __('Search videos'),
        //'not_found' => __('No videos found.'),
    );
        $args = array(
        'supports'             => $supports,
        'labels'               => $labels,
        'public'               => true,
        'publicly_queryable'   => true,
        'query_var'            => true,
		'capability_type'      => 'page',
		'rewrite'              => array( 'slug' => 'modules' ),
		'has_archive'          => true,
		'menu_position'        => 5,
		'menu_icon'            => 'dashicons-calendar-alt',
		'register_meta_box_cb' => 'wpt_add_modules_metaboxes',
		'hierarchical' => true,
		'taxonomies' => array('category', 'post_tag')
    );
    register_post_type('modules', $args);
    flush_rewrite_rules();
}

add_action('init', 'FITPRO_THEME_BTX_fun_cw_post_type_modules');


function wpt_module_image() {

    global $post;
	$course_price = get_post_meta( $post->ID, 'fitpro_th_module_image', true );

	wp_nonce_field( basename( __FILE__ ), 'course_image_nonce' );
  
	echo '<input type="text" name="module_image" value = '.$course_price.'>Image Link<br><br>';

}

function wpt_save_post_modules( $post_id, $post, $update ) {
    
    if ( ! isset( $_POST['module_image_nonce'] ) || ! wp_verify_nonce( $_POST['module_image_nonce'], basename(__FILE__) ) ) {
     		return $post_id;
     }
    $module_image =  $_POST['module_image'];
    update_post_meta( $post_id, "fitpro_th_module_image", $module_image);
}

add_action( 'save_post', 'wpt_save_post_modules', 10,3 );


function wpt_add_videos_metaboxes() {

	add_meta_box(
		'wpt_video_url_id',
		'Video URL',
		'wpt_video_url',
		'videos',
		'side',
		'high'
	);

}

function FITPRO_THEME_BTX_fun_cw_post_type_videos() {
    $supports = array(
        'title', // video title
        'editor', // video description
        //'thumbnail', // course image
        // 'excerpt',
        //'custom-fields', // custom fields
        'comments', // video comments
        'page-attributes',
    );
    $labels = array(
        'name' => _x('Videos', 'plural'),
        'singular_name' => _x('Video', 'singular'),
        'menu_name' => _x('Videos', 'admin menu'),
        'name_admin_bar' => _x('Videos', 'admin bar'),
        'add_new' => _x('Add Video', 'add new'),
        'add_new_item' => __('Add New Videos'),
        'new_item' => __('New Videos'),
        'edit_item' => __('Edit Videos'),
        'view_item' => __('View Videos'),
        'all_items' => __('All Videos'),
        //'search_items' => __('Search videos'),
        //'not_found' => __('No videos found.'),
    );
        $args = array(
        'supports'             => $supports,
        'labels'               => $labels,
        'public'               => true,
        'publicly_queryable'   => true,
        'query_var'            => true,
		'capability_type'      => 'page',
		'rewrite'              => array( 'slug' => 'videos' ),
		'has_archive'          => true,
		'menu_position'        => 5,
		'menu_icon'            => 'dashicons-calendar-alt',
		'register_meta_box_cb' => 'wpt_add_videos_metaboxes',
		'hierarchical' => true,
		'taxonomies' => array('category', 'post_tag')
    );
    register_post_type('videos', $args);
    flush_rewrite_rules();
}

add_action('init', 'FITPRO_THEME_BTX_fun_cw_post_type_videos');

function wpt_video_url() {

    global $post;
	$video_url = get_post_meta( $post->ID, 'fitpro_th_videos_url', true );

	wp_nonce_field( basename( __FILE__ ), 'video_url_nonce' );

    echo $video_url."<br>";
  
	echo '<input type="text" name="video_url" value = "Hello" required/>Video URL<br><br>';
}


 
function wpt_save_post_videos( $post_id, $post, $update ) {
    
    if ( ! isset( $_POST['video_url_nonce'] ) || ! wp_verify_nonce( $_POST['video_url_nonce'], basename(__FILE__) ) ) {
     		return $post_id;
     }
     $video_level_value =  $_POST['video_url'];
     update_post_meta( $post_id, "fitpro_th_videos_url", $video_level_value);
}
add_action( 'save_post', 'wpt_save_post_videos', 10,3 );

?>