<div class="ps-stream-repost">
	<div class="ps-stream-attachment">
		<div class="ps-stream-quote"><?php echo $content; ?></div>
	</div>
</div>