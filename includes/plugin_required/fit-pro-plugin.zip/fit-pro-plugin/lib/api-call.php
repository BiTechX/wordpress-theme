<?php
//courses module

if ( ! defined( 'ABSPATH' ) ) {
    // Call dirname() 4 times as this file is in '/wp-contents/plugins/plugin-dir/' and wp-config.php is in '/'
    require_once  dirname( dirname( dirname( dirname( dirname( __FILE__ ) ) ) ) ) . '/wp-config.php';
    
}

if (file_exists (ABSPATH.'/wp-admin/includes/taxonomy.php')) {
        require_once (ABSPATH.'/wp-admin/includes/taxonomy.php'); 
}

function FITPRO_THEME_BTX_fun_course_add_api_url(){
    $url = site_url()."/wp-json/fitpro/v1/courses/add";
    return $url;
}

function FITPRO_THEME_BTX_fun_course_add_api_make(){
    register_rest_route( 'fitpro/v1', '/courses/add', array(
        'methods' =>'post',
        'callback' => 'course_add_function',
        
        
        'args' => array(
            "title"=>array(
                    "type"=>"string",
                    'required' => true,
                ),
            "content"=>array(
                    "type"=>"string",
                    'required' => true,
                ),
            "featuredImage"=>array(
                    "type"=>"string",
                    'required' => true,
                ),
            "userLevel"=>array(
                    "type"=>"string",
                    'required' => true,
                ),
            "category"=>array(
                    "type"=>"string",
                    'required' => true,
                ),
            "tags" => array(
                    "type"=>"string",
                    'required' => true,
                )
            ),
            ""
      ));
}
add_action( 'rest_api_init', 'FITPRO_THEME_BTX_fun_course_add_api_make' );

function course_add_function( WP_REST_Request $request ) {
       
    global $wpdb;
    $paramaters = $request->get_params();
    
    $tags = explode("," , $paramaters['tags']);
    array_push($tags,strtolower($paramaters['category']));
    $name = explode(" ",strtolower($paramaters['title']));
    foreach($name as $n)
        array_push($tags,$n);
    $user_id = get_current_user_id();

    $Value = array(
        'post_author'           => $user_id,
        'post_content'          => $paramaters['content'],
        'post_title'            => $paramaters['title'],
        'post_status'           => 'publish',
        'post_type'             => 'courses',
        'tags_input'            => $tags,
        'meta_input'            => array(
                                        'fitpro_th_course_user_level' => $paramaters['userLevel'],
                                        'fitpro_th_course_image' => $paramaters['featuredImage'],
                                    ),
    );
    
    // $filename = $parameters['featuredImage'];
    $parent_post_id =   wp_insert_post($Value);
    
    // Create the category
    $id = wp_create_categories( array($paramaters['category']));
    wp_set_post_categories( $parent_post_id , $id );
    
    $Db_insert = array(
            'course_id'=>$parent_post_id,
		    'isFeatured'=>0,
		    'view_count'=>0
    );
   $db =  $wpdb->insert( course_db_name(), $Db_insert);
    
   return json_encode(array("message"=>"hello"));
        
}

function FITPRO_THEME_BTX_fun_course_update_api_url(){
    $url = site_url()."/wp-json/fitpro/v1/courses/update";
    return $url;
}

function FITPRO_THEME_BTX_fun_course_update_api_make(){
    register_rest_route( 'fitpro/v1', '/courses/update', array(
        'methods' =>'post',
        'callback' => 'course_update_function',
        
        
        'args' => array(
            "ID" => array(
                    "type"=>"string",
                    'required' => true,
                ),
            "title"=>array(
                    "type"=>"string",
                    'required' => true,
                ),
            "content"=>array(
                    "type"=>"string",
                    'required' => true,
                ),
            "featuredImage"=>array(
                    "type"=>"string",
                    'required' => true,
                ),
            "userLevel"=>array(
                    "type"=>"string",
                    'required' => true,
                ),
            "category"=>array(
                    "type"=>"string",
                    'required' => true,
                ),
            "tags" => array(
                    "type"=>"string",
                    'required' => true,
                )
            ),
            ""
      ));
}

add_action( 'rest_api_init', 'FITPRO_THEME_BTX_fun_course_update_api_make' );

function course_update_function( WP_REST_Request $request ) {
       
    $paramaters = $request->get_params();
    $user_id = get_current_user_id();
    $tags = explode("," , $paramaters['tags']);
    $Value = array(
        'ID'                    => $paramaters['ID'],
        'post_author'           => $user_id,
        'post_content'          => $paramaters['content'],
        'post_title'            => $paramaters['title'],
        'post_status'           => 'publish',
        'post_type'             => 'courses',
        'tags_input'            => $tags,
        
    );
    $level = get_post_meta($paramaters['ID'],'fitpro_th_course_user_level');
    $image = get_post_meta($paramaters['ID'],'fitpro_th_course_image');
    
    update_post_meta($paramaters['ID'],'fitpro_th_course_user_level',$paramaters['userLevel']);
    
    if(@unlink($image[0]));
    
    update_post_meta($paramaters['ID'],'fitpro_th_course_image', $paramaters['featuredImage']);
    
    // Create the category
    $id = wp_create_categories( array($paramaters['category']));
    wp_set_post_categories( $paramaters['ID'] , $id );
    wp_update_post($Value);
    
    return json_encode(array( 'status'=>"Done", "message"=>$paramaters['ID']));
}

function FITPRO_THEME_BTX_fun_course_delete_api_url(){
    $url = site_url()."/wp-json/fitpro/v1/courses/delete";
    return $url;
}

function FITPRO_THEME_BTX_fun_course_delete_api_make(){
    register_rest_route( 'fitpro/v1', '/courses/delete', array(
        'methods' =>'post',
        'callback' => 'course_delete_function',
        
        
        'args' => array(
            "ID"=>array(
                    "type"=>"string",
                    'required' => true,
                ),
            ),
            ""
      ));
}

add_action( 'rest_api_init', 'FITPRO_THEME_BTX_fun_course_delete_api_make' );

function course_delete_function( WP_REST_Request $request ) {
       
       
        global $wpdb;
        $paramaters = $request->get_params();
        
        $image = get_post_meta($paramaters['ID'],'fitpro_th_course_image');
        if(@unlink($image[0]));
        
        wp_delete_post($paramaters["ID"]);
        
        $db = $wpdb->delete( course_db_name(), array('course_id' => $paramaters["ID"]), array('%d'));
        $db = $wpdb->delete( table_subscription_info(), array('course_id' => $paramaters["ID"]), array('%d'));
        $db = $wpdb->delete( table_user_progress(), array('course_id' => $paramaters["ID"]), array('%d'));
        $modules = $wpdb->get_results("SELECT * FROM ".module_db_name()." WHERE course_id = '".$paramaters["ID"]."'" , ARRAY_A);
        foreach($modules as $module)
        {
            $videos = $wpdb->get_results("SELECT * FROM ".video_db_name()." WHERE module_id = '".$module['module_id']."'" , ARRAY_A);
            foreach($videos as $video)
            {
                wp_delete_post($video['video_id']);
                $db = $wpdb->delete( video_db_name(), array('video_id' => $video['video_id']), array('%d'));
            }
            
            $image = get_post_meta($module['module_id'],'fitpro_th_module_image');
            if(@unlink($image[0]));
            
            wp_delete_post($module['module_id']);
            $db = $wpdb->delete( module_db_name(), array('module_id' => $module['module_id']), array('%d'));
        }
        return json_encode(array( 'status'=>"1","message"=>$paramaters["ID"] ));
}

//MODULE

function FITPRO_THEME_BTX_fun_module_add_api_url(){
    $url = site_url()."/wp-json/fitpro/v1/modules/add";
    return $url;
}

function FITPRO_THEME_BTX_fun_module_add_api_make(){
    register_rest_route( 'fitpro/v1', '/modules/add', array(
        'methods' =>'post',
        'callback' => 'module_add_function',
        
        'args' => array(
            "title"=>array(
                    "type"=>"string",
                    'required' => true,
                ),
            "post_id"=>array(
                    "type"=>"string",
                    'required' => true,
                ),
            "image_link"=>array(
                    "type"=>"string",
                    'required' => true,
                ),
            ),
      ));
}
add_action( 'rest_api_init', 'FITPRO_THEME_BTX_fun_module_add_api_make' );


function module_add_function( WP_REST_Request $request ) 
{
    global $wpdb;
    $paramaters = $request->get_params();
    
    $user_id = get_current_user_id();

    $Value = array(
        'post_author'           => $user_id,
        'post_title'            => $paramaters['title'],
        'post_status'           => 'draft',
        'post_type'             => 'modules',
        'meta_input'            => array(
                                        'fitpro_th_module_image' => $paramaters['image_link'],
                                    ),
    );
    
    $post_id =  wp_insert_post($Value);
    
    $Db_insert = array(
            'module_id'=>$post_id,
		    'course_id'=>$paramaters['post_id'],
    );
   $db =  $wpdb->insert( module_db_name(), $Db_insert);
    
   return json_encode(array('status'=>"1", "message"=>$post_id));
}

function FITPRO_THEME_BTX_fun_module_update_api_url(){
    $url = site_url()."/wp-json/fitpro/v1/modules/update";
    return $url;
}

function FITPRO_THEME_BTX_fun_module_update_api_make(){
    register_rest_route( 'fitpro/v1', '/modules/update', array(
        'methods' =>'post',
        'callback' => 'module_update_function',
        
        'args' => array(
            "title"=>array(
                    "type"=>"string",
                    'required' => true,
                ),
            "module_id"=>array(
                    "type"=>"string",
                    'required' => true,
                ),
            "image_link"=>array(
                    "type"=>"string",
                    'required' => true,
                ),
            ),
            ""
      ));
}
add_action( 'rest_api_init', 'FITPRO_THEME_BTX_fun_module_update_api_make' );


function module_update_function( WP_REST_Request $request ) 
{
    global $wpdb;
    $paramaters = $request->get_params();
    
    $user_id = get_current_user_id();

    $Value = array(
        'ID'                    => $paramaters['module_id'],
        'post_author'           => $user_id,
        'post_title'            => $paramaters['title'],
        'post_status'           => 'publish',
        'post_type'             => 'modules',
    );
    
    wp_update_post($Value);
    
    update_post_meta($paramaters['module_id'],'fitpro_th_module_image', $paramaters['image_link']);
    
    return json_encode(array('status'=>"1", "message"=>$paramaters['module_id']));
}

function FITPRO_THEME_BTX_fun_module_delete_api_url(){
    $url = site_url()."/wp-json/fitpro/v1/modules/delete";
    return $url;
}

function FITPRO_THEME_BTX_fun_module_delete_api_make(){
    register_rest_route( 'fitpro/v1', '/modules/delete', array(
        'methods' =>'post',
        'callback' => 'module_delete_function',
        
        'args' => array(
            "ID"=>array(
                    "type"=>"string",
                    'required' => true,
                ),
            ),
            ""
      ));
}

add_action( 'rest_api_init', 'FITPRO_THEME_BTX_fun_module_delete_api_make' );

function module_delete_function( WP_REST_Request $request ) {
       
       
        global $wpdb;
        $paramaters = $request->get_params();
    
        $videos = $wpdb->get_results("SELECT * FROM ".video_db_name()." WHERE module_id = '".$paramaters["ID"]."'" , ARRAY_A);
        foreach($videos as $video)
        {
            wp_delete_post($video['video_id']);
            $db = $wpdb->delete( video_db_name(), array('video_id' => $video['video_id']), array('%d'));
        }
        
        $image = get_post_meta($paramaters['ID'],'fitpro_th_module_image');
        if(@unlink($image[0]));
        
        wp_delete_post($paramaters["ID"]);
        $db = $wpdb->delete( module_db_name(), array('module_id' => $paramaters["ID"]), array('%d'));
        $db = $wpdb->delete( table_user_progress(), array('module_id' => $paramaters["ID"]), array('%d'));
        $db = $wpdb->delete( table_user_progress(), array('module_id' => $paramaters["ID"]), array('%d'));
        
        return json_encode(array( 'status'=>"1","message"=>$paramaters["ID"] ));
}

//VIDEO APIS

function FITPRO_THEME_BTX_fun_video_add_api_url(){
    $url = site_url()."/wp-json/fitpro/v1/video/add";
    return $url;
}

function FITPRO_THEME_BTX_fun_video_add_api_make(){
    register_rest_route( 'fitpro/v1', '/video/add', array(
        'methods' =>'post',
        'callback' => 'video_add_function',
        
        'args' => array(
            "module_id"=>array(
                    "type"=>"string",
                    'required' => true,
                ),
            "title"=>array(
                    "type"=>"string",
                    'required' => true,
                ),
            "description"=>array(
                    "type"=>"string",
                    'required' => true,
                ),
            "url"=>array(
                    "type"=>"string",
                    'required' => true,
                ),    
            ),
      ));
}

add_action( 'rest_api_init', 'FITPRO_THEME_BTX_fun_video_add_api_make' );

function video_add_function( WP_REST_Request $request ) {
   
    global $wpdb;
    $paramaters = $request->get_params();
    
    $user_id = get_current_user_id();

    $Value = array(
        'post_author'           => $user_id,
        'post_title'            => data_validation($paramaters['title']),
        'post_content'          => data_validation($paramaters['description']),
        'post_name'             => data_validation("video_".sanitize_title($paramaters['title'])),
        'post_status'           => 'publish',
        'post_type'             => 'videos',
        'meta_input'            => array('fitpro_th_videos_url' => $paramaters['url'],),
    );
    
    $post_id =   wp_insert_post($Value);
    $Db_insert = array(
            'video_id'=>$post_id,
		    'module_id'=>$paramaters['module_id'],
    );
    $db =  $wpdb->insert( video_db_name(), $Db_insert);
    return json_encode(array('statue'=>"1","message"=>$post_id ));
}

function FITPRO_THEME_BTX_fun_video_update_api_url(){
    $url = site_url()."/wp-json/fitpro/v1/video/update";
    return $url;
}

function FITPRO_THEME_BTX_fun_video_update_api_make(){
    register_rest_route( 'fitpro/v1', '/video/update', array(
        'methods' =>'post',
        'callback' => 'video_update_function',
        
        'args' => array(
            "video_id"=>array(
                    "type"=>"string",
                    'required' => true,
                ),
            "title"=>array(
                    "type"=>"string",
                    'required' => true,
                ),
            "description"=>array(
                    "type"=>"string",
                    'required' => true,
                ),
            "url"=>array(
                    "type"=>"string",
                    'required' => true,
                ),    
            ),
      ));
}

add_action( 'rest_api_init', 'FITPRO_THEME_BTX_fun_video_update_api_make' );

function video_update_function( WP_REST_Request $request ) 
{
    global $wpdb;
    $paramaters = $request->get_params();
    
    $user_id = get_current_user_id();

    $Value = array(
        'ID'                    => $paramaters['video_id'],
        'post_author'           => $user_id,
        'post_title'            => $paramaters['title'],
        'post_content'          => $paramaters['description'],
        'post_status'           => 'publish',
        'post_type'             => 'videos',
    );
    
    wp_update_post($Value);
    
    update_post_meta($paramaters['video_id'],'fitpro_th_videos_url', $paramaters['url']);
    
    return json_encode(array('status'=>"1", "message"=>$paramaters['video_id']));
}

function FITPRO_THEME_BTX_fun_video_delete_api_url(){
    $url = site_url()."/wp-json/fitpro/v1/video/delete";
    return $url;
}

function FITPRO_THEME_BTX_fun_video_delete_api_make(){
    register_rest_route( 'fitpro/v1', '/video/delete', array(
        'methods' =>'post',
        'callback' => 'video_delete_function',
        
        'args' => array(
            "ID"=>array(
                    "type"=>"string",
                    'required' => true,
                ),
            ),
      ));
}

add_action( 'rest_api_init', 'FITPRO_THEME_BTX_fun_video_delete_api_make' );

function video_delete_function( WP_REST_Request $request ) {
   
    global $wpdb;
    $paramaters = $request->get_params();
    
    wp_delete_post($paramaters["ID"]);
    
    $db = $wpdb->delete( video_db_name(), array('video_id' => $paramaters["ID"]), array('%d'));
    
   return json_encode(array('statue'=>"1","message"=>$paramaters["ID"]  ));
}


//category Add & delete

function FITPRO_THEME_BTX_fun_add_new_category_api_url(){
    $url = site_url()."/wp-json/fitpro/v1/add/category";
    return $url;
}
add_action( 'rest_api_init', 'FITPRO_THEME_BTX_fun_add_new_category_api_make' );
function FITPRO_THEME_BTX_fun_add_new_category_api_make(){
    register_rest_route( 'fitpro/v1', '/add/category', array(
        'methods' =>'post',
        'callback' => 'add_new_category',
        
        
        'args' => array(
            "category_name"=>array(
                    "type"=>"string",
                    'required' => true,
                ),
            "category_description"=>array(
                    "type"=>"string",
                    'required' => true,
                ),
            ),
            ""
      ));
}

function add_new_category( WP_REST_Request $request ) {
       
    global $wpdb;
    $paramaters = $request->get_params();
    try{
       $category_name = data_validation($paramaters['category_name']);
       $category_description = data_validation($paramaters['category_description']);
        
        $term = term_exists( $category_name , 'category' );
        if ( $term !== 0 && $term !== null ) {
           return json_encode(array('status'=>"0","message"=> "Already have this category" ));
        }
        else{
            $wpdocs_cat = array('cat_name' => $category_name , 'category_description' => $category_description, 'category_parent' => '');
            $wpadd_cat = wp_insert_category($wpdocs_cat);
            return json_encode(array('status'=>"1","message"=> "OK" ));
        }
       
        
    }catch(Exception $e){
        return json_encode(array('status'=>"0","message"=> $e->getMessage() ));
    }
        
}

function FITPRO_THEME_BTX_fun_delete_category_api_url(){
    $url = site_url()."/wp-json/fitpro/v1/detete/category/";
    return $url;
}

add_action( 'rest_api_init', 'FITPRO_THEME_BTX_fun_delete_category_api_make' );
function FITPRO_THEME_BTX_fun_delete_category_api_make(){
    register_rest_route( 'fitpro/v1', '/detete/category/(?P<id>\d+)', array(
        'methods' =>'post',
        'callback' => 'delete_a_category',
        
        
        'args' => array(
            
            ),
            ""
      ));
}

function delete_a_category( WP_REST_Request $request ) {
       
    global $wpdb;
    $paramaters = $request->get_params();
    try{
       $categ_ID = $paramaters['id'];
 
        if ( wp_delete_category( $categ_ID ) ) {
            return json_encode(array('status'=>"1","message"=> "Successfully deleted category" ));
        } else {
            return json_encode(array('status'=>"0","message"=> "Sorry , Impossible to delete category" ));
        }
       
        
    }catch(Exception $e){
        return json_encode(array('status'=>"0","message"=> $e->getMessage() ));
    }
        
}




//payment info
//stripe Payment
function FITPRO_THEME_BTX_fun_stripe_api_key_add_api_url(){
    $url = site_url()."/wp-json/fitpro/v1/payment/stripe/api";
    return $url;
}

add_action( 'rest_api_init', 'FITPRO_THEME_BTX_fun_stripe_api_add_api_make' );
function FITPRO_THEME_BTX_fun_stripe_api_add_api_make(){
    register_rest_route( 'fitpro/v1', '/payment/stripe/api', array(
        'methods' =>'post',
        'callback' => 'stripe_api_add_function',
        
        
        'args' => array(
            "Publishable_key"=>array(
                    "type"=>"string",
                    'required' => true,
                ),
            "Secret_key"=>array(
                    "type"=>"string",
                    'required' => true,
                ),
            
            ),
            ""
      ));
}

function stripe_api_add_function( WP_REST_Request $request ) {
   
    global $wpdb;
    $paramaters = $request->get_params();
    
      $value = array(
            "Publishable_key"=>$paramaters['Publishable_key'],
            "Secret_key"=>$paramaters['Secret_key'],
            );
            
    update_option('fitpro_stripe_api',$value);
    
    
    return json_encode(array('statue'=>"1","message"=>"add stripe api successfully"  ));
}


add_action( 'rest_api_init', 'FITPRO_THEME_BTX_fun_stripe_payment_add_api_make' );
function FITPRO_THEME_BTX_fun_stripe_payment_add_api_make(){
    register_rest_route( 'fitpro/v1', '/payment/stripe/payment', array(
        'methods' =>'post',
        'callback' => 'stripe_user_payment_add_function',
        
        
        'args' => array(
            /*
            "Displayed_name"=>array(
                    "type"=>"string",
                    'required' => true,
                ),
            "Address"=>array(
                    "type"=>"string",
                    'required' => true,
                ),
            "TotalAmount"=>array(
                    "type"=>"string",
                    'required' => true,
                ),
            "currency"=>array(
                    "type"=>"string",
                    'required' => true,
                ),
                */
            
            ),
            ""
      ));
}

function stripe_user_payment_add_function( WP_REST_Request $request ) {
   
    global $wpdb;
    $paramaters = $request->get_params();
    
    try{
        $api_key = get_option('fitpro_stripe_api');
        $stripe = [
                "secret_key"      => $api_key['Secret_key'],
                "publishable_key" => $api_key['Publishable_key'],
        ];
         \Stripe\Stripe::setApiKey($stripe['secret_key']);
          $value_Stripe_token = \Stripe\Token::create([
              "card" => [
                "name"=> "Rafat",
                "address_city"=> 'Dhaka',
                "address_country"=> 'BD',
                "address_line1" =>"address" ,
                "address_zip"=>'1212',
                "number" => '4242 4242 4242 4242',
                "exp_month" => '03',
                "exp_year" => '24',
                "cvc" => '123',
                
              ]
            ]);
            
            $value_token_get =$value_Stripe_token->id;
            
              $value_Stripe_customer = \Stripe\Customer::create([
              'email' => 'rafathaque1997@gmail.com',
              "description" => "Test",
              'source'  => $value_token_get,
              "metadata"=> [
                    ]
            ]);
            
            $value_customer_get = $value_Stripe_customer->id;
             
            $value_Stripe_charge = \Stripe\Charge::create([
                'customer' => $value_customer_get,
                'amount'   => 500*100,
                'currency' => 'usd',
                'receipt_email'=>'rafathaque1997@gmail.com',
                "metadata"=> [
                    
                    ]
            ]);
            
            
            return json_encode(array('statue'=>"1","message"=> $value_Stripe_charge ));
         
    }catch(Exception $e){
        return json_encode(array('statue'=>"0","message"=> $e->getMessage() ));
    }
   
}



//paypal Payment
function FITPRO_THEME_BTX_fun_paypal_payment_url(){
    $url = site_url()."/wp-json/fitpro/v1/payment/paypal/payment/";
    return $url;
}
function FITPRO_THEME_BTX_fun_paypal_api_key_api_url(){
    $url = site_url()."/wp-json/fitpro/v1/payment/paypal/api";
    return $url;
}

add_action( 'rest_api_init', 'FITPRO_THEME_BTX_fun_paypal_api_add_api_make' );
function FITPRO_THEME_BTX_fun_paypal_api_add_api_make(){
    register_rest_route( 'fitpro/v1', '/payment/paypal/api', array(
        'methods' =>'post',
        'callback' => 'paypal_api_add_function',
        
        
        'args' => array(
            "paypal_mode"=>array(
                    "type"=>"string",
                    'required' => true,
                ),
            
            "paypal_client_live"=>array(
                    "type"=>"string",
                    'required' => true,
                ),
            "paypal_secret_live"=>array(
                    "type"=>"string",
                    'required' => true,
                ),
                
            "paypal_client_sandbox"=>array(
                    "type"=>"string",
                    'required' => true,
                ),
            "paypal_secret_sandbox"=>array(
                    "type"=>"string",
                    'required' => true,
                ),
            
            ),
            ""
      ));
}

function paypal_api_add_function( WP_REST_Request $request ) {
   
    global $wpdb;
    $paramaters = $request->get_params();
    
    
      $value = array(
            'mode' => $paramaters['paypal_mode'],
            'paypal_client_live' => $paramaters['paypal_client_live'],
            'paypal_secret_live' => $paramaters['paypal_secret_live'],
            'paypal_client_sandbox' => $paramaters['paypal_client_sandbox'],
            'paypal_secret_sandbox' => $paramaters['paypal_secret_sandbox'],
            );
            
    update_option('fitpro_paypal_api',$value);
    return json_encode(array('statue'=>"1","message"=>'update paypal successfully'  ));
}










add_action( 'rest_api_init', 'FITPRO_THEME_BTX_fun_paypal_payment_add_api_make' );
function FITPRO_THEME_BTX_fun_paypal_payment_add_api_make(){
    register_rest_route( 'fitpro/v1', '/payment/paypal/payment/', array(
        'methods' =>'post',
        'callback' => 'paypal_user_payment_add_function',
        
        
        'args' => array(
            /*
            "Displayed_name"=>array(
                    "type"=>"string",
                    'required' => true,
                ),
            "Address"=>array(
                    "type"=>"string",
                    'required' => true,
                ),
            "TotalAmount"=>array(
                    "type"=>"string",
                    'required' => true,
                ),
            "currency"=>array(
                    "type"=>"string",
                    'required' => true,
                ),
                */
            
            ),
            ""
      ));
}

function paypal_user_payment_add_function( WP_REST_Request $request ) {
   
    global $wpdb;
    $paramaters = $request->get_params();
    
    try{
        $api_key = get_option('fitpro_paypal_api');
        $apiContext = null;
        
        if(isset($api_key['mode'])){
            
            if($api_key['mode'] == 'live'){
                
                $apiContext = new \PayPal\Rest\ApiContext(
                new \PayPal\Auth\OAuthTokenCredential(
                       $api_key['paypal_client_live']."" ,     // ClientID
                       $api_key['paypal_secret_live'].""       // ClientSecret
                    )
                );
        
                 $apiContext->setConfig(
                        array(
                            'mode' => 'live',
                            'log.LogEnabled' => true,
                            'log.FileName' => 'PayPal.log',
                            'log.LogLevel' => 'DEBUG'
                            )
                        );
                        
            }
            else{
                
                $apiContext = new \PayPal\Rest\ApiContext(
                new \PayPal\Auth\OAuthTokenCredential(
                       $api_key['paypal_client_sandbox'].'' ,     // ClientID
                       $api_key['paypal_secret_sandbox'].''      // ClientSecret
                    )
                );
        
                 $apiContext->setConfig(
                        array(
                            'mode' => 'sandbox',
                            'log.LogEnabled' => true,
                            'log.FileName' => 'PayPal.log',
                            'log.LogLevel' => 'DEBUG'
                            )
                        );
                
            }
        }else{
            return json_encode(array('statue'=>"0","message"=> "paypal error find in api"  ));
        }
        
        
        $payer = new \PayPal\Api\Payer();
        $payer->setPaymentMethod('paypal');
        
        $amount = new \PayPal\Api\Amount();
        $amount->setTotal('1.00');
        $amount->setCurrency('USD');
        
        $transaction = new \PayPal\Api\Transaction();
        $transaction->setAmount($amount);
        
        $redirectUrls = new \PayPal\Api\RedirectUrls();
        $redirectUrls->setReturnUrl(site_url()."/user/payment.php")
            ->setCancelUrl(site_url()."/user/payment.php");
            
        $InputFields = new \PayPal\Api\InputFields();
        $InputFields->setNoShipping(1);
        $WebProfile = new \PayPal\Api\WebProfile();
        $WebProfile->setName( "Sport Me PayPal ".uniqid() )->setInputFields($InputFields);
        $WebProfileid = $WebProfile->create($apiContext)->getId();
        
        $payment = new \PayPal\Api\Payment();
        $payment->setExperienceProfileId( $WebProfileid );
        $payment->setIntent('sale')
            ->setPayer($payer)
            ->setTransactions(array($transaction))
            ->setRedirectUrls($redirectUrls);
            
        $payment->create($apiContext);
      
        $_SESSION['PAYPAL_TOTAL_PRICE'] = "1.00";
        return json_encode(array('status'=>"1","message"=> "find the url","url"=>$payment->getApprovalLink()  ));
         
    }catch(Exception $e){
        return json_encode(array('statue'=>"0","message"=> $e->getMessage() ));
    }
   
}





//blog uplode

function FITPRO_THEME_BTX_fun_add_new_blog_url(){
    $url = site_url()."/wp-json/fitpro/v1/blog/add";
    return $url;
}
add_action( 'rest_api_init', 'FITPRO_THEME_BTX_fun_add_new_blog_api_make' );
function FITPRO_THEME_BTX_fun_add_new_blog_api_make(){
    register_rest_route( 'fitpro/v1', '/blog/add', array(
        'methods' =>'post',
        'callback' => 'add_new_blog',
        
        'args' => array(
            "title"=>array(
                    "type"=>"string",
                    'required' => true,
                ),
             "description_blog"=>array(
                    "type"=>"string",
                    'required' => true,
                ),
             "FileLink"=>array(
                    "type"=>"string",
                    'required' => true,
                ),
            "thumbnail_id"=>array(
                    "type"=>"string",
                    'required' => true,
                ),
             "userId"=>array(
                    "type"=>"string",
                    'required' => true,
                ),
            ),
      ));
}


function Generate_Featured_Image( $image_url, $post_id  ){
    $upload_dir = wp_upload_dir();
    $image_data = file_get_contents($image_url);
    $filename = basename($image_url);
    if(wp_mkdir_p($upload_dir['path']))     $file = $upload_dir['path'] . '/' . $filename;
    else                                    $file = $upload_dir['basedir'] . '/' . $filename;
    file_put_contents($file, $image_data);

    $wp_filetype = wp_check_filetype($filename, null );
    $attachment = array(
        'post_mime_type' => $wp_filetype['type'],
        'post_title' => sanitize_file_name($filename),
        'post_content' => '',
        'post_status' => 'inherit'
    );
    $attach_id = wp_insert_attachment( $attachment, $file, $post_id );
    require_once(ABSPATH . 'wp-admin/includes/image.php');
    $attach_data = wp_generate_attachment_metadata( $attach_id, $file );
    $res1= wp_update_attachment_metadata( $attach_id, $attach_data );
    $res2= set_post_thumbnail( $post_id, $attach_id );
}
function add_new_blog( WP_REST_Request $request ) 
{
    global $wpdb;
    $paramaters = $request->get_params();
    $title = data_validation($paramaters['title']);
    $description = $paramaters['description_blog'];
    $Featured_image_url = $paramaters['FileLink'];
    $thumbnail_id = $paramaters['thumbnail_id'];
    $post_name = sanitize_title($title);
    
    $user_id = data_validation($paramaters['userId']);
       $my_post = array(
        'post_title'    => $title,
        'post_content'  => $description,
        'post_status'   => 'publish',
        'post_author'   => $user_id,
        'post_name'     => $post_name,
        'post_category' => ''
    );
     

    $id = wp_insert_post( $my_post );
    //Generate_Featured_Image($Featured_image_url , $id);
     $res2= set_post_thumbnail( $id, $thumbnail_id );
    
   return json_encode(array('status'=>"1", "message"=>$id));
}


function FITPRO_THEME_BTX_fun_edit_new_blog_url(){
    $url = site_url()."/wp-json/fitpro/v1/blog/edit/";
    return $url;
}
add_action( 'rest_api_init', 'FITPRO_THEME_BTX_fun_edit_new_blog_api_make' );
function FITPRO_THEME_BTX_fun_edit_new_blog_api_make(){
    register_rest_route( 'fitpro/v1', '/blog/edit/(?P<id>\d+)', array(
        'methods' =>'post',
        'callback' => 'edit_new_blog',
        
        'args' => array(
            "title"=>array(
                    "type"=>"string",
                    'required' => true,
                ),
             "description_blog"=>array(
                    "type"=>"string",
                    'required' => true,
                ),
             "name"=>array(
                    "type"=>"string",
                    'required' => true,
                ),
             "FileLink"=>array(
                    "type"=>"string",
                    'required' => true,
                ),
            "thumbnail_id"=>array(
                    "type"=>"string",
                    'required' => true,
                ),
            "userId"=>array(
                    "type"=>"string",
                    'required' => true,
                ),
            ),
      ));
}


function edit_new_blog( WP_REST_Request $request ) 
{
    global $wpdb;
    $paramaters = $request->get_params();
    $title = data_validation($paramaters['title']);
    $description = $paramaters['description_blog'];
    $Featured_image_url = $paramaters['FileLink'];
    $thumbnail_id = $paramaters['thumbnail_id'];
    $post_name = sanitize_title($paramaters['name']);
    $user_id = data_validation($paramaters['userId']);
    $post_id = data_validation($paramaters['id']);
    
      $my_post = array(
        'ID'           => $post_id,  
        'post_title'    => $title,
        'post_content'  => $description,
        'post_status'   => 'publish',
        'post_author'   => $user_id,
        'post_name'     => $post_name,
        'post_category' => ''
    );
     

    $id = wp_update_post( $my_post );
   
    $res2= set_post_thumbnail( $id, $thumbnail_id );
    
   return json_encode(array('status'=>"1", "message"=>$id));
}



















//User Info Update
function FITPRO_THEME_BTX_fun_user_info_update_url(){
    $url = site_url()."/wp-json/fitpro/v1/user/update/";
    return $url;
}
function FITPRO_THEME_BTX_fun_user_info_update_password_url(){
    $url = site_url()."/wp-json/fitpro/v1/user/updatePass/";
    return $url;
}
add_action( 'rest_api_init', 'FITPRO_THEME_BTX_fun_user_info_update' );
function FITPRO_THEME_BTX_fun_user_info_update(){
    register_rest_route( 'fitpro/v1', '/user/update/(?P<id>\d+)', array(
        'methods' =>'post',
        'callback' => 'user_info_update_function',
        
        
        'args' => array(
            "user_nicename"=>array(
                    "type"=>"string",
                    'required' => true,
                ),
            "first_name"=>array(
                    "type"=>"string",
                    'required' => true,
                ),
            "last_name"=>array(
                    "type"=>"string",
                    'required' => true,
                ),
            "mobile_number"=>array(
                    "type"=>"string",
                    'required' => true,
                ),
            "description"=>array(
                    "type"=>"string",
                    'required' => true,
                ),
            ),
            ""
      ));
}

function user_info_update_function( WP_REST_Request $request ) {
        try{
            global $wpdb;
            $paramaters = $request->get_params();
            
            $user_id = $paramaters['id'];
            $user_nicename= data_validation($paramaters['user_nicename']);
            $first_name = data_validation($paramaters['first_name']);
            $last_name = data_validation($paramaters['last_name']);
            $display_name = $first_name ." ". $last_name;
            $mobile_number = data_validation($paramaters['mobile_number']);
            $description = data_validation($paramaters['description']);
            $country_name = data_validation($paramaters['country_name']);
            $user_height = data_validation($paramaters['user_height']);
            $user_weight = data_validation($paramaters['user_weight']);
            $user_facebook = data_validation($paramaters['facebook']."");
            $user_twitter = data_validation($paramaters['twitter']."");
            $user_linkedIn = data_validation($paramaters['linkedIn']."");
            $user_instagram = data_validation($paramaters['instagram']."");
            $user_short_title = data_validation($paramaters['title']);
           
           $user_data = wp_update_user( 
                array( 
                    'ID' => $user_id, 
                    'user_nicename' => $user_nicename ,
                    'first_name'   => $first_name,
                    'last_name'   => $last_name,
                    'display_name' => $display_name ,
                    'description' => $description ,
                    ) 
                
                );
               
               
              
                
            $havemeta = get_user_meta($user_id, 'mobile_number', true);
            if($havemeta){
                $updated = update_user_meta( $user_id, 'mobile_number', $mobile_number );
            }
            else{
                add_user_meta( $user_id, 'mobile_number', $mobile_number);
            }
                
            $havemeta = get_user_meta($user_id, 'user_weight', true);
            if($havemeta){
                $updated = update_user_meta( $user_id, 'user_weight', $user_weight );
            }
            else{
                add_user_meta( $user_id, 'user_weight', $user_weight);
            }
        
        
            $havemeta = get_user_meta($user_id, 'user_height', true);
            if($havemeta){
                $updated = update_user_meta( $user_id, 'user_height', $user_height );
            }
            else{
                add_user_meta( $user_id, 'user_height', $user_height);
            }
            
        
            $havemeta = get_user_meta($user_id, 'country', true);
            if($havemeta){
                $updated = update_user_meta( $user_id, 'country', $country_name );
            }
            else{
                add_user_meta( $user_id, 'country', $country_name);
            }
            
            $havemeta = get_user_meta($user_id, 'facebook', true);
            if($havemeta){
                $updated = update_user_meta( $user_id, 'facebook', $user_facebook );
            }
            else{
                update_user_meta( $user_id, 'facebook', $user_facebook );
            }
        
            $havemeta = get_user_meta($user_id, 'twitter', true);
            if($havemeta){
                $updated = update_user_meta( $user_id, 'twitter', $user_twitter );
            }
            else{
                update_user_meta( $user_id, 'twitter', $user_twitter);
            }
        
        
            $havemeta = get_user_meta($user_id, 'linkedin', true);
            if($havemeta){
                $updated = update_user_meta( $user_id, 'linkedin', $user_linkedIn );
            }
            else{
                update_user_meta( $user_id, 'linkedin', $user_linkedIn);
            }
            
            $havemeta = get_user_meta($user_id, 'instagram', true);
            if($havemeta){
                $updated = update_user_meta( $user_id, 'instagram', $user_instagram );
            }
            else{
                update_user_meta( $user_id, 'instagram', $user_instagram);
            }
            
            $havemeta = get_user_meta($user_id, 'user_short_title', true);
            if($havemeta){
                $updated = update_user_meta( $user_id, 'user_short_title', $user_short_title );
            }
            else{
                add_user_meta( $user_id, 'user_short_title', $user_short_title);
            }
            
        
        return json_encode(array('statue'=>"1","message"=>$paramaters ));
        }catch(Exception $e){
            return json_encode(array('statue'=>"0","message"=> $e->getMessage() ));
        }
   }


add_action( 'rest_api_init', 'FITPRO_THEME_BTX_fun_user_password_update' );
function FITPRO_THEME_BTX_fun_user_password_update(){
    register_rest_route( 'fitpro/v1', '/user/updatePass/(?P<id>\d+)', array(
        'methods' =>'post',
        'callback' => 'user_info_update_password_function',
        
        
        'args' => array(
            "old_password"=>array(
                    "type"=>"string",
                    'required' => true,
                ),
            "new_password"=>array(
                    "type"=>"string",
                    'required' => true,
                ),
            ),
            ""
      ));
}

function user_info_update_password_function( WP_REST_Request $request ) {
        try{
            global $wpdb;
            $paramaters = $request->get_params();
            $status_message = array();
            
            $user_ID = $paramaters['id'];
            $oldPassword = $paramaters['old_password'];
            $newPassword = $paramaters['new_password'];
             $mess = "";
             
            if($oldPassword == $newPassword){
                $mess = " Your old & new password is same ! ";
                $status_message['status'] = "0";
                $status_message['message'] = $mess;
                return json_encode($status_message);
            }
            
            $user_Info = get_userdata( $user_ID );
            $user = get_user_by( 'login', $user_Info->user_login );
           
            
            if ( $user && wp_check_password( $oldPassword,  $user->data->user_pass , $user_ID  ) ){
                 $mess =  "That's it";
                 $mess = wp_set_password($newPassword , $user_ID);
                 $status_message['status'] = "1";
                 $status_message['message'] = $mess;
            }
            else{
                $mess = " Please give old password correctly ! ";
                $status_message['status'] = "0";
                $status_message['message'] = $mess;
            }
               
            return json_encode($status_message);
           
        }catch(Exception $e){
            return json_encode(array('statue'=>"0","message"=> $e->getMessage() ));
        }
   }




//theme Color Change
function FITPRO_THEME_BTX_fun_theme_color_change_url(){
    $url = site_url()."/wp-json/fitpro/v1/theme/color";
    return $url;
}
function FITPRO_THEME_BTX_fun_theme_color_reset_url(){
    $url = site_url()."/wp-json/fitpro/v1/theme/color/reset";
    return $url;
}
add_action( 'rest_api_init', 'FITPRO_THEME_BTX_fun_theme_color_change_api_make' );
function FITPRO_THEME_BTX_fun_theme_color_change_api_make(){
    register_rest_route( 'fitpro/v1', '/theme/color', array(
        'methods' =>'post',
        'callback' => 'theme_color_change_function',
        
        
        'args' => array(
            "primary_color_1"=>array(
                    "type"=>"string",
                    'required' => true,
                ),
            "primary_color_2"=>array(
                    "type"=>"string",
                    'required' => true,
                ),
            "secondary_color_1"=>array(
                    "type"=>"string",
                    'required' => true,
                ),
            "secondary_color_2"=>array(
                    "type"=>"string",
                    'required' => true,
                ),
            "homepage_image_link"=>array(
                    "type"=>"string",
                    'required' => true,
                ),
            "courseprogress_image_link"=>array(
                    "type"=>"string",
                    'required' => true,
                ),
           
            ),
            ""
      ));
}



function theme_color_change_function( WP_REST_Request $request ) {
       
    global $wpdb;
    $paramaters = $request->get_params();
    
    
    $options = get_option( 'theme_setting_change' );

    $primary_color_1_HEX = $options['opt-primary-color-1'];
    $primary_color_2_HEX = $options['opt-primary-color-2'];
    $secondary_color_1_HEX = $options['opt-secondary-color-1'];
    $secondary_color_2_HEX = $options['opt-secondary-color-2'];
    $homepage_image_link = $options['opt-text-homepage-image-link']; 
    $courseprogress_image_link = $options['opt-text-courseprogress-image-link']; 
    
    /* $value = array(
        'opt-primary-color-1' => $primary_color_1_HEX,
        'opt-primary-color-2'=>$primary_color_2_HEX,
        'opt-secondary-color-1'=>$secondary_color_1_HEX,
        'opt-secondary-color-2'=>$secondary_color_2_HEX,
        );
    */
    //add_option( 'theme_setting_change',$value , '', 'yes' );
    
    $primary_color_1_HEX = $paramaters['primary_color_1'];
    $primary_color_2_HEX = $paramaters['primary_color_2'];
    $secondary_color_1_HEX = $paramaters['secondary_color_1'];
    $secondary_color_2_HEX = $paramaters['secondary_color_2'];
    $homepage_image_link = $paramaters['homepage_image_link']; 
    $courseprogress_image_link = $paramaters['courseprogress_image_link']; 
    
    $value = array(
        'opt-primary-color-1'=>$primary_color_1_HEX,
        'opt-primary-color-2'=>$primary_color_2_HEX,
        'opt-secondary-color-1'=>$secondary_color_1_HEX,
        'opt-secondary-color-2'=>$secondary_color_2_HEX,
        'opt-text-homepage-image-link'=>$homepage_image_link,
        'opt-text-courseprogress-image-link'=>$courseprogress_image_link,
        );
  
    update_option('theme_setting_change',$value);
  
   return json_encode(array('status'=> '1' ,"message"=>$paramaters  ));
        
}

add_action( 'rest_api_init', 'FITPRO_THEME_BTX_fun_theme_color_reset_api_make' );
function FITPRO_THEME_BTX_fun_theme_color_reset_api_make(){
    register_rest_route( 'fitpro/v1', '/theme/color/reset', array(
        'methods' =>'post',
        'callback' => 'theme_color_reset_function',
        
        
        'args' => array(
            /*
            "primary_color_1"=>array(
                    "type"=>"string",
                    'required' => true,
                ),
            "primary_color_2"=>array(
                    "type"=>"string",
                    'required' => true,
                ),
            "secondary_color_1"=>array(
                    "type"=>"string",
                    'required' => true,
                ),
            "secondary_color_2"=>array(
                    "type"=>"string",
                    'required' => true,
                ),
           */
            ),
            ""
      ));
}



function theme_color_reset_function( WP_REST_Request $request ) {
       
    global $wpdb;
    $paramaters = $request->get_params();
    
    
    $options = get_option( 'theme_setting_change' );

    delete_option( 'theme_setting_change' ); 
  
   return json_encode(array('status'=> '1' ,"message"=>$paramaters  ));
        
}









function FITPRO_THEME_BTX_fun_admin_user_status_change_url(){
    $url = site_url()."/wp-json/fitpro/v1/admin/user/status/";
    return $url;
}
add_action( 'rest_api_init', 'FITPRO_THEME_BTX_fun_admin_user_status_change_api_make' );
function FITPRO_THEME_BTX_fun_admin_user_status_change_api_make(){
    register_rest_route( 'fitpro/v1', '/admin/user/status/(?P<id>\d+)', array(
        'methods' =>'post',
        'callback' => 'user_status_change',
        
        'args' => array(
            
            "user_status"=>array(
                    "type"=>"string",
                    'required' => true,
                ),
                
            ),
      ));
}


function user_status_change( WP_REST_Request $request ) 
{
    global $wpdb;
    $paramaters = $request->get_params();
    $user_status = $paramaters['user_status'];
    $user_id = $paramaters['id'];
    if($user_status == 'deactivate'){
        $updated = update_user_meta( $user_id, 'account_status', 'spam' );
    }
    else if($user_status == 'activate'){
        $updated = update_user_meta( $user_id, 'account_status', 'approved' );
    }
    else if($user_status == 'delete'){
        require_once( ABSPATH.'wp-admin/includes/user.php' );
        wp_delete_user($user_id);
    }
    
   return json_encode(array('status'=>"1", "message"=>"ok"));
}









//plan All Api control
require_once FITPRO_CONTROLLER_DIR_PATH.'/lib/api/all_plan_control.php';
require_once FITPRO_CONTROLLER_DIR_PATH.'/lib/api/chat_control.php';

