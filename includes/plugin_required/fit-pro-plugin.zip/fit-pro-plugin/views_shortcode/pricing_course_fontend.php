<?php 
    global $wpdb;
    $tableName = plan_db_info();
    $result = get_all_plan();
    
   
    $last_row_rem = count($result)%3;
    $last_row_div = ceil( count($result)/3 );
    
    //echo $last_row_div;
?>


    <div class="et_pb_section et_pb_section_15 flip-card-section et_pb_with_background et_section_regular" style="background-color:transparent;">
  
        <div class="et_pb_row" style="max-width:600px;">
            <div class="et_pb_column et_pb_column_4_4    et_pb_css_mix_blend_mode_passthrough et-last-child">

                <div class="et_pb_module et_pb_text  et_pb_bg_layout_light  et_pb_text_align_left">

                    <div class="et_pb_text_inner">
                        <h1 class="primary-color1" style="text-align: center;">ENROLL TODAY</h1>
                        <p class="primary-color1" style="text-align: center;">Select convenient monthly installments, or save over $1,000 plus get all the bonuses with a single payment</p>
                    <!--    <p class="primary-color1" style="text-align: center;">Or, you can invest yourself in learning the business building principles and strategies that Erin and Jason and so many others have committed themselves to.</p>
                        <p class="primary-color1" style="text-align: center;"><strong>By leveraging the proven 6-step process, you can build a thriving coaching business in 6 months or less without the never ending struggle and the revenue roller coaster.</strong></p>-->
                    </div>
                </div>
                <!-- .et_pb_text -->
            </div>
            <!-- .et_pb_column -->

        </div>
      
        <?php 
        $i = 0;
        $j = 0;
        foreach($result as $val): 
            $i++;
            if($val->plan_is_featured == 0):
 ?> 
        <!-- .et_pb_row -->
        <div class="et_pb_row flip-card" style="height:350px;">
            <div class="et_pb_column et_pb_column_4_4  flip-card-inner  et_pb_css_mix_blend_mode_passthrough et-last-child">

                <div class="et_pb_module et_pb_text  flip-card-front white-overlay et_pb_bg_layout_light et_pb_text_align_left" style="background-image:url('https://fitprobizlaunch.com/wp-content/uploads/2019/05/Layer-6.jpg');background-size:cover;">

                    <div class="et_pb_text_inner" style="height:300px;padding:30px;">

                        <h6 class="primary-color1" style="text-align: center;height:100px;margin:auto;"><?php echo $val->plan_title; ?></h6>
                        <h1 class="primary-color1" style="text-align: center;height:100px;">
                             <?php 
                             echo '$'.$val->plan_total_cost.' / ' ;
                            if($val->plan_type == '1'){
                                echo ' ONE TIME';
                            }
                            else if($val->plan_type == '2'){
                                echo ' MONTHLY';
                            }
                            else if($val->plan_type == '3'){
                                echo ' MONTHLY';
                            }
                            else if($val->plan_type == '4'){
                                echo $val->plane_name;
                            }
                           
                        ?>
                        </h1>
                    </div>

                </div>

                <!-- .et_pb_text -->
                <div class="et_pb_module et_pb_text  flip-card-back primary-color2-background primary-color1 et_pb_bg_layout_light  et_pb_text_align_left">

                    <div class="et_pb_text_inner"  style="height:250px;padding:30px;">
                        <p class="primary-color1"><?php echo $val->plan_description; ?></p>
                    </div>
                    <div class="et_pb_button_module_wrapper et_pb_button_2_wrapper et_pb_module  et_pb_text_align_center">
        				<a class="et_pb_button white theme-rounded-button primary-color1-background primary-color1-border primary-color1-border-hover white-hover et_pb_bg_layout_light" href="">ENROLL NOW</a>
        			</div>
                </div>
                <!-- .et_pb_text -->
            </div>
            <!-- .et_pb_column -->

        </div>
 <?php  
        elseif($val->plan_is_featured == 1):
 ?> 
        <!-- This is featured price div -->
        <!-- .et_pb_row -->
        <div class="et_pb_row flip-card" style="height:350px;">
            <div class="et_pb_column et_pb_column_4_4  flip-card-inner  et_pb_css_mix_blend_mode_passthrough et-last-child">

                <div class="et_pb_module et_pb_text  flip-card-front  secondary-color1-overlay et_pb_bg_layout_light  et_pb_text_align_left" style="background-image:url('https://fitprobizlaunch.com/wp-content/uploads/2019/05/Layer-6.jpg');background-size:cover;">

                    <div class="et_pb_text_inner" style="height:300px;padding:30px;padding-top:0px;text-align:center;">
                        
                        <img src="https://fitprobizlaunch.com/wp-content/uploads/2019/05/star.svg" style="margin-bottom:2px;">
                        <h6 class="white" style="text-align: center;height:100px;margin:auto;"><?php echo $val->plan_title; ?></h6>
                        <h1 class="white" style="text-align: center;height:100px;">
                        <?php 
                            
                            echo '$'.$val->plan_total_cost.' / ' ;
                            if($val->plan_type == '1'){
                                echo $val->plane_name;
                            }
                            else if($val->plan_type == '2'){
                                echo $val->plane_name;
                            }
                            else if($val->plan_type == '3'){
                                echo $val->plane_name;
                            }
                            else if($val->plan_type == '4'){
                                echo $val->plane_name;
                            }
                        ?>
                        
                        </h1>
                    </div>

                </div>

                <!-- .et_pb_text -->
                <div class="et_pb_module et_pb_text  flip-card-back primary-color2-background primary-color1 et_pb_bg_layout_light  et_pb_text_align_left">

                    <div class="et_pb_text_inner"  style="height:250px;padding:30px;">
                        <p class="primary-color1"><?php echo $val->plan_description; ?></p>
                    </div>
                    <div class="et_pb_button_module_wrapper et_pb_button_2_wrapper et_pb_module  et_pb_text_align_center">
        				<a class="et_pb_button white theme-rounded-button primary-color1-background primary-color1-border primary-color1-border-hover white-hover et_pb_bg_layout_light" href="">ENROLL NOW</a>
        			</div>
                </div>
                <!-- .et_pb_text -->
            </div>
            <!-- .et_pb_column -->

        </div>
        
        <!-- .et_pb_row -->
      <!--  <div class="et_pb_row flip-card" style="height:350px;">
            <div class="et_pb_column et_pb_column_4_4  flip-card-inner  et_pb_css_mix_blend_mode_passthrough et-last-child">

                <div class="et_pb_module et_pb_text  flip-card-front white-overlay et_pb_bg_layout_light  et_pb_text_align_left" style="background-image:url('https://fitprobizlaunch.com/wp-content/uploads/2019/05/Layer-6.jpg');background-size:cover;">

                    <div class="et_pb_text_inner" style="height:300px;padding:30px;">

                        <h6 class="primary-color1" style="text-align: center;height:100px;">BUSINESS LAUNCHER BASIC</h6>
                        <h1 class="primary-color1" style="text-align: center;height:100px;">$1050/Mo</h1>
                    </div>

                </div>

                <!-- .et_pb_text -->
            <!--    <div class="et_pb_module et_pb_text  flip-card-back primary-color2-background primary-color1 et_pb_bg_layout_light  et_pb_text_align_left">

                    <div class="et_pb_text_inner"  style="height:250px;padding:30px;">
                        <p>The exact formula for Value Driven Enrollment so you never have to use cheesy sales tactics ever again.</p>
                    </div>
                    <div class="et_pb_button_module_wrapper et_pb_button_2_wrapper et_pb_module  et_pb_text_align_center">
        				<a class="et_pb_button white theme-rounded-button primary-color1-background primary-color1-border primary-color1-border-hover white-hover et_pb_bg_layout_light" href="">ENROLL NOW</a>
        			</div>
                </div>
                <!-- .et_pb_text -->
        <!--    </div>
            <!-- .et_pb_column -->

     <!--   </div>-->
        <!-- .et_pb_row -->
       <?php  
         endif;
          if(count($result) != 4){   
            if($i%3 == 0 ){
                $j++;
        ?>
        <div class="et_pb_row divider_row">
            <div class="et_pb_column et_pb_column_4_4   et_pb_css_mix_blend_mode_passthrough et-last-child">

                <div class="et_pb_module et_pb_divider et_pb_divider_0 et_pb_divider_position_ et_pb_space">
                    <div class="et_pb_divider_internal"></div>
                </div>
            </div>
            <!-- .et_pb_column -->

        </div>

<?php 
            }
        }else if(count($result) == 4){
                if($i%2 == 0 ){
        ?>
         <div class="et_pb_row divider_row">
            <div class="et_pb_column et_pb_column_4_4   et_pb_css_mix_blend_mode_passthrough et-last-child">

                <div class="et_pb_module et_pb_divider et_pb_divider_0 et_pb_divider_position_ et_pb_space">
                    <div class="et_pb_divider_internal"></div>
                </div>
            </div>
            <!-- .et_pb_column -->

        </div>
        
        <?php
                }
        }
endforeach; 
?>  
    </div>