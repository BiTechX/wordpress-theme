<h3 style="color: #00b0ff; margin: 0; padding: 0; font-size: 26px; line-height: 30px;">
    <a href="{siteurl}" style="text-decoration: none; color: #00b0ff;">{sitename}</a>
</h3>