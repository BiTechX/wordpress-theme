<?php
echo $content;